//
//  ViewController.h
//  album-songslist
//
//  Created by Hemant Gupta on 24/03/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>

@interface ViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    IBOutlet UITableView *tab1;
}

@end

