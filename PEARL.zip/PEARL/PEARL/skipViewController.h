//
//  skipViewController.h
//  PEARL
//
//  Created by kavi on 07/12/16.
//  Copyright © 2016 kavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface skipViewController : UIViewController<UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UITableViewDelegate,UITableViewDataSource>
{
    IBOutlet UIImageView *skpimg;
    IBOutlet UINavigationBar *nbar;
    IBOutlet UIBarButtonItem *back;
  // IBOutlet UICollectionView *grid;
    //IBOutlet UITableView *tablegrid;
    NSMutableArray *dataArray, *imgarray, *clrary;
    
    UICollectionView *collect;
}

@property(nonatomic,weak) NSString *dlt;

@end
