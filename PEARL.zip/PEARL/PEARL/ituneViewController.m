//
//  ituneViewController.m
//  PEARL
//
//  Created by kavi on 07/01/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import "ituneViewController.h"
#import "TableViewCell.h"


@interface ituneViewController ()
{
    TableViewCell *cell;
    
    NSArray *mainarr;
    NSArray *mainarr2;
    // NSArray *mainarr1;
    NSDictionary *Response;
    
    NSURL *url;
    NSURLConnection *connection;
    NSURLRequest *request;
    NSMutableData *Data;

}

@end

@implementation ituneViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [tab registerNib:[UINib nibWithNibName:@"TableViewCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"cell"];
    
    [self retrieveddata];
    

    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    
     cell=[tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    cell.name.text=[[[mainarr objectAtIndex:indexPath.row]valueForKey:@"title"]valueForKey:@"label"];
    NSLog(@"label::%@::",[[[[Response valueForKey:@"feed"]valueForKey:@"author"]valueForKey:@"name"]valueForKey:@"label"]);
    
    
    return  cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    return 100;
}
-(void)retrieveddata;
{
    url=[[NSURL alloc]initWithString:@"https://itunes.apple.com/in/rss/topfreemacapps/limit=10/json"];
    request=[NSURLRequest requestWithURL:url];
    Data=[[NSMutableData alloc]init];
    connection =[[NSURLConnection alloc]initWithRequest:request delegate:self];
    
    // [connection start];
    
    
    
    
}
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error;
{
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"failed" message:@"failed and try again" delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:@"ok",nil];
    [alert show];
}
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data;
{
    [Data appendData:data];
    //[connection start];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection;
{
    NSError *err;
    Response=[NSJSONSerialization JSONObjectWithData:Data options:NSJSONReadingMutableContainers error:&err];
    NSLog(@"%@::response",Response);
    mainarr=[[Response valueForKey:@"feed"]valueForKey:@"entry"];
    NSLog(@"mainarr::%@",mainarr);
    
    [tab reloadData];
    
    
}


@end
