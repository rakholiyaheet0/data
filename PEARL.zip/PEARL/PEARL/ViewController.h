//
//  ViewController.h
//  PEARL
//
//  Created by kavi on 06/12/16.
//  Copyright © 2016 kavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
@interface ViewController : UIViewController<UIAlertViewDelegate>

{
    IBOutlet UINavigationBar *nbar;
    
    IBOutlet UIImageView *img;
    IBOutlet UIImageView *img2;
    IBOutlet UIImageView *img3;
    IBOutlet UIBarButtonItem *menu;
    IBOutlet UIView *menuv;
    BOOL kavi, touchup;
    IBOutlet UIButton *touch;
    IBOutlet UILabel *lbl1;
    IBOutlet UILabel *lbl2;
    
    IBOutlet UITextField *txt1, *txt2, *txt3, *txt4;
    IBOutlet UITextField *txt5;
    IBOutlet UITextField *txt6;
    IBOutlet UIButton *skip;
    IBOutlet UIButton *reg;
    IBOutlet UIButton *reset;
    IBOutlet UIImageView *img4;
    IBOutlet UIButton *user;
    IBOutlet UIButton *admin;
    IBOutlet UILabel *menuname;
    
    IBOutlet UIButton *aboutpearl;
    IBOutlet UIButton *contactus;
    IBOutlet UIButton *manageid;
    IBOutlet UIButton *logout;
}

@property(strong,nonatomic) NSString *strng;

@end

