//
//  ADViewController.h
//  PEARL
//
//  Created by kavi on 11/12/16.
//  Copyright © 2016 kavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ADViewController : UIViewController
{
    IBOutlet UITextField *add;
    IBOutlet UITextField *dlt;
    IBOutlet UIButton *addbtn;
    IBOutlet UIButton *dltbtn;
    IBOutlet UIButton *done;
}

@property(nonatomic,strong) NSString *trans;

@end
