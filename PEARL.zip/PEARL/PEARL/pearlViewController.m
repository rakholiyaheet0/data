//
//  pearlViewController.m
//  PEARL
//
//  Created by kavi on 07/12/16.
//  Copyright © 2016 kavi. All rights reserved.
//

#import "pearlViewController.h"
#import "ViewController.h"


@interface pearlViewController ()

@end

@implementation pearlViewController
@synthesize title;


- (void)viewDidLoad {
    [super viewDidLoad];
    
       
    NSLog(@"%@",title);
    
    if ([title isEqualToString:@"about"]) {
            usbar.topItem.title=@"About Pearl"  ;
        smail.hidden=true;
        mail.enabled=false;
        //abtprl=[[UIView alloc]init];
        //abtprl.backgroundColor=[UIColor redColor];
        //[self.view addSubview:abtprl];
        abtpl.image=[UIImage imageNamed:@"about.png"];
        abt.frame=CGRectMake(187, 525, 0, 0);
        [UIView animateWithDuration:1.70 animations:^{
            abt.frame=CGRectMake(112, 425, 150 , 150);
        }];
        
        
    }
    else if ([title isEqualToString:@"Contact"])
    {
        usbar.topItem.title=@"Contact Us"  ;
        abtpl.image=[UIImage imageNamed:@"contact.png"];
        abt.frame=CGRectMake(187, 525, 0, 0);
        [UIView animateWithDuration:1.70 animations:^{
            
            abt.frame=CGRectMake(112, 425, 150 , 150);
        }];

       
        }
     


    }
    
    
   
    // Do any additional setup after loading the view from its nib.


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)usback:(id)sender {
    
    [self.navigationController popToRootViewControllerAnimated:YES];
}
- (IBAction)mail:(id)sender {
    
    if ([MFMailComposeViewController canSendMail]) {
        
        MFMailComposeViewController *mfmail=[[MFMailComposeViewController alloc]init];
        
        mfmail.mailComposeDelegate=self;
        [mfmail setToRecipients:@[@"ka_Vish@outlook.com"]];
        //[self presentViewController:mfmail animated:YES completion:NULL];
      //  [self.window.rootViewController presentModalViewController:mfmail animated:YES];
       // [mfmail release];
        
   }
    else NSLog(@"Hah. No mail for you.");
}
- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(nullable NSError *)error __OSX_AVAILABLE_STARTING(__MAC_NA,__IPHONE_3_0);
{
    switch (result) {
        case MFMailComposeResultSent:
            NSLog(@"You sent the email.");
            break;
        case MFMailComposeResultSaved:
            NSLog(@"You saved a draft of this email");
            break;
        case MFMailComposeResultCancelled:
            NSLog(@"You cancelled sending this email.");
            break;
        case MFMailComposeResultFailed:
            NSLog(@"Mail failed:  An error occurred when trying to compose this email");
            break;
        default:
            NSLog(@"An error occurred when trying to compose this email");
            break;
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
