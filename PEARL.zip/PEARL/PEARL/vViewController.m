//
//  vViewController.m
//  PEARL
//
//  Created by kavi on 05/01/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import "vViewController.h"
#import "ViewController4.h"

@interface vViewController ()
{
    NSMutableArray *arr;
    NSMutableArray *arr2;
    BOOL me;
   // NSString *state;
    UILabel *data;
    
}

@end

@implementation vViewController
@synthesize selectedCells,selecedStates;

- (void)viewDidLoad {
    [super viewDidLoad];
    

    
    arr=[[NSMutableArray alloc]initWithObjects:@"kavi", @"heet", @"vin", @"raj",nil];
   // arr2=nil;
    me=true;
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView;
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    return 4;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    
    //cell.accessoryType=UITableViewCellAccessoryCheckmark;
    cell.textLabel.text=[arr objectAtIndex:indexPath.row];
    //[cell addSubview:box];
    
       return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{

  }
-(BOOL)isRowSelectedOnTableView:(UITableView *)tableView atIndexPath:(NSIndexPath *)indexPath
{
    return ([self.selectedCells containsObject:indexPath]) ? YES : NO;
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath NS_AVAILABLE_IOS(3_0);
{
    UIImageView *box=[[UIImageView alloc]init];
    box.image=[UIImage imageNamed:@"nill.png"];;
}

- (IBAction)button:(id)sender
{
    NSLog(@"%@",selecedStates);

    ViewController4 *v4=[[ViewController4 alloc]init];
    
    v4.newarr=selecedStates;
    [self.navigationController pushViewController:v4 animated:YES];
    
}



@end
