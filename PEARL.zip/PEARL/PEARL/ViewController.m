//
//  ViewController.m
//  PEARL
//
//  Created by kavi on 06/12/16.
//  Copyright © 2016 kavi. All rights reserved.
//

#import "ViewController.h"
#import "skipViewController.h"
#import "pearlViewController.h"
#import "ADViewController.h"
#import "vViewController.h"
#import "ituneViewController.h"


@interface ViewController ()


@end

@implementation ViewController
@synthesize strng;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    touch.titleLabel.textColor=nil;
    touch.hidden=true;
    
    img2.image=[UIImage imageNamed:@"3.png"];
    
       
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Pearl inc." message:@"WelCome User" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];

    [alert show];
    

    menuv.hidden=true;
    
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    
    nbar.backgroundColor=[UIColor grayColor];
    img2.layer.cornerRadius=22;
    img2.layer.masksToBounds=YES;
    img2.layer.borderWidth=0.5;
    
    kavi=true;
    touchup=true;
   // menuv.backgroundColor=[UIColor grayColor];
    menuv.layer.cornerRadius=3;
    menuv.layer.masksToBounds=YES;
    menuv.layer.borderWidth=2;
    // Do any additional setup after loading the view, typically from a nib.
   txt1.layer.cornerRadius=14;
    txt1.layer.borderColor = UIColor.redColor.CGColor;
    txt1.layer.borderWidth = 1;
    txt1.layer.masksToBounds = true;
    
    txt2.layer.cornerRadius=14;
    txt2.layer.borderColor = UIColor.redColor.CGColor;
    txt2.layer.borderWidth = 1;
    txt2.layer.masksToBounds = true;
    
    txt3.layer.cornerRadius=14;
    txt3.layer.borderColor = UIColor.redColor.CGColor;
    txt3.layer.borderWidth = 1;
    txt3.layer.masksToBounds = true;
    
    txt4.layer.cornerRadius=14;
    txt4.layer.borderColor = UIColor.redColor.CGColor;
    txt4.layer.borderWidth = 1;
    txt4.layer.masksToBounds = true;
    
    txt5.layer.cornerRadius=14;
    txt5.layer.borderColor = UIColor.blackColor.CGColor;
    txt5.layer.borderWidth = 1;
    txt5.layer.masksToBounds = true;
    txt5.secureTextEntry=YES;
    
    txt6.layer.cornerRadius=14;
    txt6.layer.borderColor = UIColor.blackColor.CGColor;
    txt6.layer.borderWidth = 1;
    txt6.layer.masksToBounds = true;
    txt6.secureTextEntry=YES;
    
    
    img4.layer.cornerRadius=61;
    img4.layer.borderWidth=1.2;
    img4.layer.borderColor=UIColor.grayColor.CGColor;
    img4.layer.masksToBounds=YES;
    
    img4.image=[UIImage imageNamed:@"8.png"];

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)menu:(id)sender {
    
    if (kavi==true && touchup==true) {
        menuv.hidden=false;
        menuv.frame=CGRectMake(0, 350, 0, 0);
        [UIView animateWithDuration:0.65 animations:^{
            menuv.frame=CGRectMake(0, 71, 283 , 592);
        }];

         touch.hidden=false;
        touch.titleLabel.textColor=Nil;
        img2.image=[UIImage imageNamed:@"4.png"];
        
        kavi=false;
        touchup=false;
       
        

        
    }
    else if (kavi==false) {
       // menuv.hidden=true;
        
        menuv.frame=CGRectMake(0, 71, 283, 592);
        [UIView animateWithDuration:.50 animations:^{
            menuv.frame=CGRectMake(0, 200, 0 , 0);
        }];
         touch.hidden=true;
        img2.image=[UIImage imageNamed:@"3.png"];
        
        kavi=true;
        touchup=true;

    }
   }
- (IBAction)touch:(id)sender {
    
   // menuv.hidden=true;
    menuv.frame=CGRectMake(0, 71, 283, 592);
    [UIView animateWithDuration:.50 animations:^{
        menuv.frame=CGRectMake(0, 550, 0 , 0);
    }];
    
    touch.hidden=true;
    
    img2.image=[UIImage imageNamed:@"3.png"];

    
    kavi=true;
    touchup=true;
}
- (IBAction)skip:(id)sender {
    
    skipViewController *skp=[[skipViewController alloc]initWithNibName:@"skipViewController" bundle:nil];
    
    [self.navigationController pushViewController:skp animated:YES];
    
   
    
    UIAlertView *alert1=[[UIAlertView alloc]initWithTitle:@"Caution..!!" message:@"Are you Sure to skip, You can not use some feature." delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
    [alert1 show];

    
    NSLog(@"skippp");
    
}
- (IBAction)reg:(id)sender {
    
    vViewController *v1=[[vViewController alloc]initWithNibName:@"vViewController" bundle:nil];
    [self.navigationController pushViewController:v1 animated:YES];
    
    UIAlertView *alert1=[[UIAlertView alloc]initWithTitle:@"Caution..!!" message:@"Are you Sure to skip, You can not use some feature." delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
    [alert1 show];

    
    NSLog(@"loveu");
}
- (IBAction)reset:(id)sender {
    
    ituneViewController *itune=[[ituneViewController alloc]init];
    [self.navigationController pushViewController:itune animated:YES];
}
- (IBAction)user:(id)sender {
}
- (IBAction)admin:(id)sender {
    
    ADViewController *addmin=[[ADViewController alloc]initWithNibName:@"ADViewController" bundle:Nil];
    [self.navigationController pushViewController:addmin animated:YES];
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex NS_DEPRECATED_IOS(2_0, 9_0);
{
   if (buttonIndex == 0)
   {
       [self.navigationController popToRootViewControllerAnimated:YES];
   }
}
- (IBAction)aboutpearl:(id)sender {
    
    pearlViewController *pearl=[[pearlViewController alloc]initWithNibName:@"pearlViewController" bundle:nil];
    [self.navigationController pushViewController:pearl animated:YES];
    
    strng=@"about";
    pearl.title=strng;
    
   
}
- (IBAction)contactus:(id)sender {
    pearlViewController *pearl=[[pearlViewController alloc]initWithNibName:@"pearlViewController" bundle:nil];
    [self.navigationController pushViewController:pearl animated:YES];
    
    strng=@"Contact";
    pearl.title=strng;

}
- (IBAction)manageid:(id)sender {
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Pearl inc." message:@"WelCome User" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];

}
- (IBAction)logout:(id)sender {
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Pearl inc." message:@"WelCome User" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];

}


@end
