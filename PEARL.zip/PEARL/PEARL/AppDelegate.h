//
//  AppDelegate.h
//  PEARL
//
//  Created by kavi on 06/12/16.
//  Copyright © 2016 kavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

