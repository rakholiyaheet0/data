//
//  pearlViewController.h
//  PEARL
//
//  Created by kavi on 07/12/16.
//  Copyright © 2016 kavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import <Foundation/Foundation.h>
#import <Messages/Messages.h>

@interface pearlViewController : UIViewController<MFMailComposeViewControllerDelegate>
{
    IBOutlet UIImageView *usimg;
    IBOutlet UINavigationBar *usbar;
    IBOutlet UIBarButtonItem *usback;
    //IBOutlet UIView *abtprl;
    IBOutlet UIImageView *abtpl;
    IBOutlet UIImageView *abt;
    IBOutlet UILabel *smail;
    IBOutlet UIBarButtonItem *mail;
   // BOOL animation;
    
    
    
}
@property(weak,nonatomic) NSString *title;
@end
