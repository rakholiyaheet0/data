//
//  TableViewCell.h
//  PEARL
//
//  Created by kavi on 07/01/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell
{
    
}
@property(strong,nonatomic) IBOutlet UILabel *name;

@end
