//
//  vViewController.h
//  PEARL
//
//  Created by kavi on 05/01/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface vViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    IBOutlet UITableView *vk;
    
    IBOutlet UIButton *button;
}
@property (nonatomic, strong) NSMutableArray *selectedCells;
@property (nonatomic, strong) NSMutableArray *selecedStates;
@end
