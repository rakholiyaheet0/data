//
//  skipViewController.m
//  PEARL
//
//  Created by kavi on 07/12/16.
//  Copyright © 2016 kavi. All rights reserved.
//

#import "skipViewController.h"

@interface skipViewController ()

@end

@implementation skipViewController
@synthesize dlt;



- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    
    dlt=[defaults objectForKey:@"dlt"];
    
   // tablegrid.layer.backgroundColor=nil;
    
    UITableView *table=[[UITableView alloc]initWithFrame:CGRectMake(10, 150, 300, 600) style:UITableViewStylePlain];
    table.delegate=self;
   // table.prefetchDataSource=self;
    table.dataSource=self;
    
    UICollectionViewFlowLayout *layout=[[UICollectionViewFlowLayout alloc]init];
    collect=[[UICollectionView alloc]initWithFrame:CGRectMake(20, 150, 334, 450) collectionViewLayout:layout];
    [collect setDataSource:self];
    [collect setDelegate:self];
    
    [collect registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"cellIdentifier"];
    [collect setBackgroundColor:Nil];
    
    [self.view addSubview:collect];

   // collect.prefetchDataSource=self;
    table.backgroundColor=Nil;
  //  [self.view addSubview:table];
    
    
    dataArray=[[NSMutableArray alloc]initWithObjects:@"kavi",@"vinas", @"hardik", @"manish", nil];
    imgarray=[[NSMutableArray alloc]initWithObjects:[UIImage imageNamed:@"3.png"],[UIImage imageNamed:@"3.png"],[UIImage imageNamed:@"4.png"],[UIImage imageNamed:@"4.png"],nil];
    
    clrary=[[NSMutableArray alloc]initWithObjects:@"kavi",@"Vinas", @"Hardik", @"Avadh",@"Parth", @"Anand", nil];
    
   // dlt=@"kavi";
    NSLog(@"%@",dlt);
    
    UITextField *rm=[[UITextField alloc]init];
    rm.text=dlt;
    
   // [clrary removeObject:[@"%@",rm.text]];
    [clrary addObject:rm.text];
   // [clrary replaceObjectAtIndex:2 withObject:@"Love"];
    
   // UIImageView *tbimg=[[UIImageView alloc]initWithFrame:CGRectMake(10, 10, 22, 22)];
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)back:(id)sender {
    
    [self.navigationController popToRootViewControllerAnimated:YES];
}
//-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
 //   return 1;
//}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return clrary.count;
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cellIdentifier" forIndexPath:indexPath];

   // cell.frame=CGRectMake(20, 20, 150, 150);
    UIImageView *tbimg=[[UIImageView alloc]initWithFrame:CGRectMake(10, 10, 150 , 150)];
    
 // tbimg.image=[imgarray objectAtIndex:indexPath.row];
//[cell addSubview:tbimg];
    
    cell.layer.borderWidth=1;
    cell.layer.masksToBounds=YES;
    //cell.layer.cornerRadius=80;
    
    UILabel *lbl=[[UILabel alloc]initWithFrame:CGRectMake(10, 2, 150, 20)];
    lbl.textAlignment=NSTextAlignmentCenter;
    lbl.text=[clrary objectAtIndex:indexPath.row];
    [cell addSubview:lbl];
    
    cell.backgroundColor=nil;
    return cell;
    
}
- (CGSize) collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(160  , 160);
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath;
{
    UIAlertView *alrt=[[UIAlertView alloc]initWithTitle:@"Hello.." message:@"U r Here" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alrt show];
}
- (BOOL)collectionView:(UICollectionView *)collectionView shouldHighlightItemAtIndexPath:(NSIndexPath *)indexPath;
{
    return YES;
}












- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView;
{
    return  1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    return 16;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    return 150;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    cell.textLabel.text=[dataArray objectAtIndex:indexPath.row];
    cell.textLabel.textAlignment=NSTextAlignmentCenter;
   // cell.imageView.frame=CGRectMake(5, 5, 22, 22);
//UIImageView *tbimg=[[UIImageView alloc]initWithFrame:CGRectMake(10, 10, 130 , 130)];
    //[cell.imageView setBounds:CGRectMake(10, 10, 22, 22)];
    
   
   // cell.backgroundColor= (__bridge UIColor * _Nullable)(UIColor.redColor.CGColor);
   // tbimg.image=[imgarray objectAtIndex:indexPath.row];
  //  [cell addSubview:tbimg];
   // cell.imageView.frame=CGRectMake(10, 5, 10, 10);
    return cell;
    
}


@end
