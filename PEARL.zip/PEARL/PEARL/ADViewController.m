//
//  ADViewController.m
//  PEARL
//
//  Created by kavi on 11/12/16.
//  Copyright © 2016 kavi. All rights reserved.
//

#import "ADViewController.h"
#import "skipViewController.h"

@interface ADViewController ()

@end

@implementation ADViewController

@synthesize trans;


- (void)viewDidLoad {
    [super viewDidLoad];
    
    
   // NSUserDefaults *data=[NSUserDefaults alloc]init;
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)add:(id)sender {
    
    [add resignFirstResponder];
    
    trans=[add text];
    
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    
    [defaults setObject:trans forKey:@"dlt"];
    [defaults synchronize];
    
    NSLog(@"done");
    
    
    
}
- (IBAction)dlt:(id)sender {
}
- (IBAction)done:(id)sender {
    
    [self.navigationController popToRootViewControllerAnimated:YES];
}

@end
