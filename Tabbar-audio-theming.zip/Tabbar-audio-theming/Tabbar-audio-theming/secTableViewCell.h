//
//  secTableViewCell.h
//  Tabbar-audio-theming
//
//  Created by Hemant Gupta on 24/03/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface secTableViewCell : UITableViewCell
@property(strong,nonatomic)IBOutlet UILabel *title1;
@property(strong,nonatomic)IBOutlet UILabel *subtitle;


@end
