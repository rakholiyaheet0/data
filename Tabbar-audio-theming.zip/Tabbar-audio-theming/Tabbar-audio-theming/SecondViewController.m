//
//  SecondViewController.m
//  Tabbar-audio-theming
//
//  Created by Hemant Gupta on 24/03/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import "SecondViewController.h"
#import "secTableViewCell.h"

@interface SecondViewController ()
{
    secTableViewCell *cell1;
}

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    MPMediaQuery *songsQuery = [MPMediaQuery songsQuery];
    NSArray *songs = [songsQuery items];
    
    return [songs count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //static NSString *CellIdentifier = @"Cell";
    cell1 = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    // Configure the cell...
    
    MPMediaQuery *songsQuery = [MPMediaQuery songsQuery];
    NSArray *songs = [songsQuery items];
    MPMediaItem *rowItem = [songs objectAtIndex:indexPath.row];
    
    cell1.title1.text = [rowItem valueForProperty:MPMediaItemPropertyTitle];
    cell1.subtitle.text = [rowItem valueForProperty:MPMediaItemPropertyArtist];
    return cell1;
}

@end
