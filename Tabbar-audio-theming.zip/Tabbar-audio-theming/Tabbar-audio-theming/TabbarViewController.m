//
//  ViewController.m
//  Tabbar-audio-theming
//
//  Created by Hemant Gupta on 24/03/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import "TabbarViewController.h"

@interface TabbarViewController ()

@end

@implementation TabbarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UITabBar *tab = self.tabBar;
    UITabBarItem *tabBarItem1 = [tab.items objectAtIndex:0];
    UITabBarItem *tabBarItem2 = [tab.items objectAtIndex:1];
    UITabBarItem *tabBarItem3 = [tab.items objectAtIndex:2];
    
    tabBarItem1.title = @"Songs";
    tabBarItem2.title = @"Album";
    tabBarItem3.title = @"Player";
    [[UITabBarItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName : [UIColor whiteColor] }
                                             forState:UIControlStateNormal];
    [[UITabBarItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName : [UIColor yellowColor] }
                                             forState:UIControlStateSelected];
    
     [[UITabBar appearance] setSelectedImageTintColor:[UIColor yellowColor]];
    
     [[UITabBar appearance] setBarTintColor:[UIColor blackColor]];
   // [tabBarItem1 setFinishedSelectedImage:[UIImage imageNamed:@"songs.jpeg"] withFinishedUnselectedImage:[UIImage imageNamed:@"songs.jpeg"]];
    //[tabBarItem2 setFinishedSelectedImage:[UIImage imageNamed:@"album.jpeg"] withFinishedUnselectedImage:[UIImage imageNamed:@"album.jpeg"]];

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

@end
