//
//  main.m
//  interview databasetask
//
//  Created by radadiya on 16/04/15.
//  Copyright (c) 2015 radadiya. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
