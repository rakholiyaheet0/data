//
//  ViewController.m
//  interview databasetask
//
//  Created by radadiya on 16/04/15.
//  Copyright (c) 2015 radadiya. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSLog(@"%@/Documents",NSHomeDirectory());
    unmtxt.delegate=self;
    passtxt.delegate=self;
    fnmtxt.delegate=self;
    lnmtxt.delegate=self;
    dobtxt.delegate=self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField==dobtxt)
    {
      [UIView animateWithDuration:0.75f animations:^{
          datepicker1.frame=CGRectMake(0, 412, 320,85);}];
        [dobtxt resignFirstResponder];
        return NO;
    }
    return YES;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
  
    return NO;
}
-(BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    if (textField==dobtxt)
    {
        [UIView animateWithDuration:0.75f animations:^{
            datepicker1.frame=CGRectMake(0, 568, 320,85);}];
    }
    if (textField==passtxt)
    {
        if (passtxt.text.length<=6)
        {
            UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"you have enter short password" message:@"please enter valid password length" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
            [alt show];
        }
    }
    if (textField.text.length<=0)
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"please enter any data in the textfield" message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
    }
    return YES;
}
- (IBAction)selecteddate:(id)sender
{
    dobtxt.text=[NSString stringWithFormat:@"%@",datepicker1.date];
}

- (IBAction)submiteclick:(id)sender
{
    SKDatabase *regdata=[[SKDatabase alloc]initWithFile:@"exam.sqlite"];
    NSString *val;
    if (genderseg.selectedSegmentIndex==0)
    {
        val=@"M";
    }
    else if (genderseg.selectedSegmentIndex==1)
    {
        val=@"F";
    }
    
    NSString *regquery=[NSString stringWithFormat:@"insert into userdata (firstnm,lastnm,usernm,pass,dob,gender) VALUES ('%@','%@','%@','%@','%@','%@')",fnmtxt.text,lnmtxt.text,unmtxt.text,passtxt.text,dobtxt.text,val];
    
    [regdata lookupAllForSQL:regquery];
    [self clearall];

}
-(void)clearall
{
    unmtxt.text=nil;
    passtxt.text=nil;
    fnmtxt.text=nil;
    lnmtxt.text=nil;
    dobtxt.text=nil;
    [UIView animateWithDuration:0.75f animations:^{
        datepicker1.frame=CGRectMake(0, 568, 320,85);}];
    UIAlertView *at=[[UIAlertView alloc]initWithTitle:@"you have succesfully registerd" message:@"please go to login and make login" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
    [at show];
}
@end
