//
//  userlist.m
//  interview databasetask
//
//  Created by radadiya on 16/04/15.
//  Copyright (c) 2015 radadiya. All rights reserved.
//

#import "userlist.h"

@interface userlist ()
{
    NSMutableArray *dicarr;
    NSMutableArray *arr;
    CGPoint p;
    SKDatabase *dataforlist;
    UILongPressGestureRecognizer *lg;
    NSIndexPath *index;
    
}
@end

@implementation userlist

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self getrecord];
    lg=[[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(getsclick:)];
    lg.minimumPressDuration=1;
    lg.numberOfTapsRequired=1;
    [table3 addGestureRecognizer:lg];
    table3.delegate=self;
   
}
-(void)viewDidAppear:(BOOL)animated
{
    [table3 reloadData];
}
#pragma mark - tableviewdelegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dicarr.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    NSString *str=[NSString stringWithFormat:@"%@",[[dicarr objectAtIndex:indexPath.row]valueForKey:@"usernm"]];
    cell.textLabel.text=str;
    return cell;
}
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle==UITableViewCellEditingStyleDelete)
    {
        SKDatabase *deldata=[[SKDatabase alloc]initWithFile:@"exam.sqlite"];
        NSString *strQuery=[NSString stringWithFormat: @"delete from userdata where usernm='%@'",[[dicarr objectAtIndex:indexPath.row]valueForKey:@"usernm"]];
        [deldata lookupAllForSQL:strQuery];
        NSString *userval=[[NSUserDefaults standardUserDefaults]valueForKey:@"currentuser"];
        if (userval==[[dicarr objectAtIndex:indexPath.row]valueForKey:@"usernm"])
        {
            [[NSUserDefaults standardUserDefaults]removeObjectForKey:[NSString stringWithFormat:@"%@",[[dicarr objectAtIndex:indexPath.row]valueForKey:@"usernm"]]];
            [[NSUserDefaults standardUserDefaults]synchronize];
        }
    }
    [self getrecord];
    [table3 reloadData];
}
-(void)getrecord
{
    dataforlist=[[SKDatabase alloc]initWithFile:@"exam.sqlite"];
    NSString *queryforlist=[NSString stringWithFormat:@"select * from userdata"];
    dicarr=(NSMutableArray*)[dataforlist lookupAllForSQL:queryforlist];
}
-(void)getsclick:(UILongPressGestureRecognizer*)getsurerecog
{
    p=[getsurerecog locationInView:table3];
    index=[table3 indexPathForRowAtPoint:p];
    [table3 removeGestureRecognizer:lg];
    UIAlertView *aler= [[UIAlertView alloc]initWithTitle:@"Select Choice" message:@"Delete Record ?" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles: @"Delete", nil];
    [aler show];
    [self viewDidLoad];
    
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex==1)
    {
        NSString *QueryDelete=[NSString stringWithFormat:@"delete  from register where (usernm='%@')",[[dicarr objectAtIndex:index.row]valueForKey:@"usernm"]];
        [dataforlist lookupRowForSQL:QueryDelete];
       // [MArr removeObjectAtIndex:index.row];
        [table3 reloadData];
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
@end
