//
//  userdetailsview.m
//  interview databasetask
//
//  Created by radadiya on 16/04/15.
//  Copyright (c) 2015 radadiya. All rights reserved.
//

#import "userdetailsview.h"

@interface userdetailsview ()
{
    SKDatabase *profdata;
    NSString *uservalue;
    NSMutableArray *listarr;
    NSMutableArray *list;
}
@end

@implementation userdetailsview

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    uservalue=[[NSUserDefaults standardUserDefaults]valueForKey:@"currentuser"];
    NSLog(@"%@",uservalue);
    [[NSUserDefaults standardUserDefaults]synchronize];
    profdata=[[SKDatabase alloc]initWithFile:@"exam.sqlite"];
    NSString *listquery=[NSString stringWithFormat:@"select * from userdata where usernm='%@'",uservalue];
    listarr=(NSMutableArray*)[[[profdata lookupAllForSQL:listquery]objectAtIndex:0] allValues];
    NSLog(@"%@",listarr);

    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)deleteaccount:(UIButton*)sender
{
    NSString *delaccunt=[NSString stringWithFormat:@"delete from userdata where usernm='%@'",uservalue];
    [profdata lookupAllForSQL:delaccunt];
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(IBAction)logout:(UIButton*)sender
{
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"currentuser"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    [self dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark - tableviewdelegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return listarr.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell1=[tableView dequeueReusableCellWithIdentifier:@"cell1" forIndexPath:indexPath];
    cell1.textLabel.text=[listarr objectAtIndex:indexPath.row];
    return cell1;
}
@end

