//
//  loginform.m
//  interview databasetask
//
//  Created by radadiya on 16/04/15.
//  Copyright (c) 2015 radadiya. All rights reserved.
//

#import "loginform.h"
#import "userdetailsview.h"
#import <sqlite3.h>
@interface loginform ()
{
    userdetailsview *detail;
    NSString *uval;
    NSMutableArray *arr;
    NSMutableDictionary *dic;
 }
@end

@implementation loginform

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
     detail=[self.storyboard instantiateViewControllerWithIdentifier:@"userdetailsview"];
    uval=[[NSUserDefaults standardUserDefaults]valueForKey:@"currentuser"];
   //[[NSUserDefaults standardUserDefaults]removeObjectForKey:@"currentuser"];
    [[NSUserDefaults standardUserDefaults]synchronize];

    NSLog(@"%@",uval);
    if (uval!=NULL)
    {
       [self pushtodetail];
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
-(IBAction)loginclick:(UIButton*)sender
{
    SKDatabase *logindata=[[SKDatabase alloc]initWithFile:@"exam.sqlite"];
    arr=(NSMutableArray *)[logindata lookupRowForSQL:[NSString stringWithFormat:@"select * from userdata where usernm='%@' AND pass='%@'",unmtxt.text,passtxt.text]];
    if ([unmtxt.text length] && [passtxt.text length] >0 && [arr valueForKey:@"usernm"] &&[arr valueForKey:@"pass"])
    {
        [[NSUserDefaults standardUserDefaults]setValue:unmtxt.text forKey:@"currentuser"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        [self pushtodetail];
    }
    else
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Check User Name And Password" message:nil delegate:nil cancelButtonTitle:@"Cancel" otherButtonTitles:@"Ok", nil];
        [alert show];
    }
}
-(void)pushtodetail
{
    [self presentViewController:detail animated:YES completion:nil];
}
@end
