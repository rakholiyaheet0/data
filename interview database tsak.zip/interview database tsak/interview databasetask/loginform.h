//
//  loginform.h
//  interview databasetask
//
//  Created by radadiya on 16/04/15.
//  Copyright (c) 2015 radadiya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SKDatabase.h"
@interface loginform : UIViewController<SKDatabaseDelegate>
{
    IBOutlet UITextField *unmtxt;
    IBOutlet UITextField *passtxt;
}
-(IBAction)loginclick:(UIButton*)sender;
@end
