//
//  ViewController.h
//  interview databasetask
//
//  Created by radadiya on 16/04/15.
//  Copyright (c) 2015 radadiya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SKDatabase.h"
@interface ViewController : UIViewController<UITextFieldDelegate,SKDatabaseDelegate>
{
    IBOutlet UITextField *unmtxt;
    IBOutlet UITextField *dobtxt;
    IBOutlet UISegmentedControl *genderseg;
    IBOutlet UITextField *lnmtxt;
    IBOutlet UITextField *fnmtxt;
    IBOutlet UITextField *passtxt;
    IBOutlet UIDatePicker *datepicker1;
    
}
- (IBAction)submiteclick:(id)sender;
- (IBAction)selecteddate:(id)sender;

@end
