//
//  ViewController.m
//  database-hitesh
//
//  Created by hitesh rakholiya on 07/01/17.
//  Copyright (c) 2017 hitesh rakholiya. All rights reserved.
//

#import "ViewController.h"
#import "Constant.h"
#import <sqlite3.h>

@interface ViewController ()

@end

@implementation ViewController
@synthesize Name_lbl,id_lbl,Des_lbl,NAME_TEXT;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)InsertClick:(id)sender
{
    
    NSString *insertQuery = [NSString stringWithFormat:@"INSERT INTO heettab VALUES ('%ld','%@','%@')",(long)_ID_TEXT.text.integerValue,NAME_TEXT.text,_DES_TEXT.text];
    
    
    [APPDELEGATE.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
         [db executeUpdate:insertQuery];
     }];
    
    [self clearalltextfields];
    [self clearalllabel];
    //Name_lbl.text=NAME_TEXT.text;
    NSLog(@"%@",Name_lbl.text);
    
}
- (IBAction)DeleteClick:(id)sender
{
    NSString *deleteQuery =[NSString stringWithFormat:@"DELETE FROM heettab WHERE Emp_Id ='%d'",_ID_TEXT.text.intValue];
    
    [APPDELEGATE.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
         [db executeUpdate:deleteQuery];
     }];
    
    [self clearalltextfields];
    [self clearalllabel];
    
}
- (IBAction)Select_Click:(id)sender
{
    
    NSString *sqlSelectQuery =[NSString stringWithFormat:@"SELECT * FROM heettab where Emp_Id=%ld",(long)_ID_TEXT.text.integerValue] ;
    
    [APPDELEGATE.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
         
         FMResultSet *resultsWithCollegeName = [db executeQuery:sqlSelectQuery];
         
         while([resultsWithCollegeName next])
         {
             
             id_lbl.text=[NSString stringWithFormat:@"%d",[resultsWithCollegeName intForColumn:@"Emp_Id"]];
             
             Name_lbl.text= [NSString stringWithFormat:@"%@",[resultsWithCollegeName stringForColumn:@"Emp_Name"]];
             
             Des_lbl.text=[NSString stringWithFormat:@"%@",[resultsWithCollegeName stringForColumn:@"Emp_Des"]];
             
         }
     }];
    
    [self clearalltextfields];
}
- (IBAction)Update_Click:(id)sender
{
    NSString *updateQuery = [NSString stringWithFormat:@"UPDATE heettab SET Emp_Name= '%@',Emp_Des='%@' WHERE Emp_Id='%d'",NAME_TEXT.text,_DES_TEXT.text,_ID_TEXT.text.intValue];
    
    [APPDELEGATE.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
         [db executeUpdate:updateQuery];
     }];
    
    [self clearalltextfields];
    [self clearalllabel];
    
}

- (IBAction)Bulk_Insert_Click:(id)sender
{
    
    // Insert Bulk Data
    //[self Insert_Bulk_Data];
    
    // Select Bulk Data
    //[self Select_Bulk_Data];
    
}

-(void)Insert_Bulk_Data
{
    //    NSString *delete_data=[NSString stringWithFormat:@"DELETE FROM Bulk_DataTable WHERE user_id='%@'",[USERDEFAULTS valueForKey:@"current_user_id"]];
    //
    //    [APPDELEGATE.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
    //     {
    //         [db executeUpdate:delete_data];
    //     }];
    //
    //    NSString *res_st=[APPDELEGATE Convert_arr_From_Json_String:responsearr];
    //
    //    NSString *t_str=[APPDELEGATE Convert_arr_From_Json_String:top_five_art_arr];
    //
    //    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    //    [dict setObject:[USERDEFAULTS valueForKey:@"current_user_id"] forKey:@"user_id"];
    //
    //    [dict setObject:t_str forKey:@"topfive_article"];
    //    [dict setObject:res_st forKey:@"listing_article"];
    //
    //    // ADD Dictionary In database Table with  FMDATABASE AND SKDATABASE
    //
    //    //[Database insertDictionary:dict forTable:@"INSIGHT_OPENION"];
    //
    //    [APPDELEGATE.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
    //     {
    //         [db executeUpdate:@"INSERT INTO INSIGHT_OPENION (user_id,topfive_article,listing_article) VALUES (:user_id,:topfive_article,:listing_article)" withParameterDictionary:dict];
    //     }];
    
}

-(void)Select_Bulk_Data
{
    //    NSString *sqlSelectQuery =[NSString stringWithFormat:@"SELECT * FROM INSIGHT_OPENION where user_id=%ld",(long)[[USERDEFAULTS valueForKey:@"current_user_id"]integerValue]] ;
    //
    //    [APPDELEGATE.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
    //     {
    //
    //         FMResultSet *dataset = [db executeQuery:sqlSelectQuery];
    //
    //         while([dataset next])
    //         {
    //             responsearr=[APPDELEGATE Convert_Json_String_From_Arr:[dataset stringForColumn:@"listing_article"]];
    //
    //
    //             top_five_art_arr=[APPDELEGATE Convert_Json_String_From_Arr:[dataset stringForColumn:@"topfive_article"]];
    //         }
    //     }];
    //
    //    if (!responsearr.count>0)
    //    {
    //        SHOW_ALERT(@"Alert",@"There is no data in database please connect internet to access this functionality", nil, @"Ok", nil);
    //        return;
    //    }
    
}

-(void)clearalltextfields
{
    NAME_TEXT.text=nil;
    _ID_TEXT.text=nil;
    _DES_TEXT.text=nil;
}

-(void)clearalllabel
{
    Name_lbl.text=nil;
    id_lbl.text=nil;
    Des_lbl.text=nil;
}

@end
