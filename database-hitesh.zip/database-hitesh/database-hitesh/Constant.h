//
//  Constant.h
//  IMA
//
//  Created by Jignesh Radadiya on 6/30/15.
//  Copyright (c) 2015 Credencys. All rights reserved.
//

#ifndef IMA_Constant_h
#define IMA_Constant_h

//-------------------------------------------------------------
// set AlertView Instance
//--------------------------------------------------------------
#define Show_Alert(AlertTitle,AlertMsg) { \
UIAlertController * alert= [UIAlertController alertControllerWithTitle:AlertTitle message:AlertMsg preferredStyle:UIAlertControllerStyleAlert]; \
UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {[alert dismissViewControllerAnimated:YES completion:nil];}]; \
[alert addAction:ok];\
[self presentViewController:alert animated:YES completion:nil];\
}
//Set Internet Alert
//---------------------------------------------
#define SHOW_INTERNET_ALERT { \
UIAlertController * alert= [UIAlertController alertControllerWithTitle:@"No Internet Detected!" message:@"Please check and verify that you have Internet access." preferredStyle:UIAlertControllerStyleAlert]; \
UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {[alert dismissViewControllerAnimated:YES completion:nil];}]; \
[alert addAction:ok];\
[self presentViewController:alert animated:YES completion:nil];\
}

//Set Connection Fail Alert
//-----------------------------------------

#define SHOW_CONNECTION_FAIL_ALERT { \
UIAlertController * alert= [UIAlertController alertControllerWithTitle:@"Connection fail" message:@"Please check and verify that you have Internet access." preferredStyle:UIAlertControllerStyleAlert]; \
UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {[alert dismissViewControllerAnimated:YES completion:nil];}]; \
[alert addAction:ok];\
[self presentViewController:alert animated:YES completion:nil];\
}
//-------------------------------------------------------------
// set SERVER BUSY AlertView Instance
#define SHOW_SERVER_BUSY_ALERT { \
UIAlertController * alert= [UIAlertController alertControllerWithTitle:@"Server temporarily down!" message:@"Our server is being updated at the moment.  We apologize for the inconvenience.  It should be up shortly.  Please try again later." preferredStyle:UIAlertControllerStyleAlert]; \
UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {[alert dismissViewControllerAnimated:YES completion:nil];}]; \
[alert addAction:ok];\
[self presentViewController:alert animated:YES completion:nil];\
}
//-----------------------------------------------------------------------------
#define IS_OS_8_OR_LATER ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
//-------------------------------------------------------------
#define ROBOTO_REGULAR_FONT12 [UIFont fontWithName:@"Roboto-Regular" size:12]
#define ROBOTO_BOLD_FONT12 [UIFont fontWithName:@"Roboto-Bold" size:12]

#define ROBOTO_REGULAR_FONT14 [UIFont fontWithName:@"Roboto-Regular" size:14]
#define ROBOTO_BOLD_FONT14 [UIFont fontWithName:@"Roboto-Bold" size:14]

#define ROBOTO_REGULAR_FONT16 [UIFont fontWithName:@"HelveticaNeue-Thin" size:16]
#define ROBOTO_BOLD_FONT16 [UIFont fontWithName:@"Roboto-Bold" size:16]

#define ROBOTO_REGULAR_FONT18 [UIFont fontWithName:@"Roboto-Regular" size:18]
#define ROBOTO_BOLD_FONT18 [UIFont fontWithName:@"Roboto-Bold" size:18]

#define ROBOTO_REGULAR_FONT20 [UIFont fontWithName:@"Roboto-Regular" size:20]
#define ROBOTO_BOLD_FONT20 [UIFont fontWithName:@"Roboto-Bold" size:20]

#define ACCEPTABLE_CHARECTERS @"0123456789"
//-------------------------------------------------------------
#pragma mark - Application Delegate
#import "AppDelegate.h"
#define APPDELEGATE ((AppDelegate*)[[UIApplication sharedApplication] delegate])

//-------------------------------------------------------------
#pragma mark - NSUserDefault
#define USERDEFAULTS [NSUserDefaults standardUserDefaults]

//-------------------------------------------------------------
#pragma mark - Document Directory path
#define DOCUMENTS_FOLDER [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]

//-------------------------------------------------------------

//-------------------------------------------------------------
#pragma mark - AsyncImageView


//-------------------------------------------------------------
#pragma mark - Rechability

//-------------------------------------------------------------
#define SCREEN_HEIGHT [[UIScreen mainScreen] bounds].size.height
#define SCREEN_WIDTH [[UIScreen mainScreen] bounds].size.width
#define IS_IPHONE4_OR_4S [[UIScreen mainScreen] bounds].size.height == 480.0f
#define IS_IPHONE5_OR_5S [[UIScreen mainScreen] bounds].size.height == 568.0f
#define IS_IPHONE6 [[UIScreen mainScreen] bounds].size.height == 667.0f
#define IS_IPHONE6pluse [[UIScreen mainScreen] bounds].size.height == 736.0f
#define VIEW_BORDER_COLOR [UIColor colorWithRed:109/255.0 green:110/255.0 blue:113/255.0 alpha:1.0]

#define LIGHTTEXT_COLOR [UIColor colorWithRed:167/255.0 green:169/255.0 blue:172/255.0 alpha:1.000]
#define DARKTEXT_COLOR [UIColor colorWithRed:109/255.0 green:110/255.0 blue:113/255.0 alpha:1.0]
#define RED_COLOR [UIColor colorWithRed:202/255.0 green:32/255.0 blue:39/255.0 alpha:1.0]

//-------------------------------------------------------------
//-------------------------------------------------------------
#endif