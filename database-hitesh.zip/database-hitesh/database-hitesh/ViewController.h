//
//  ViewController.h
//  database-hitesh
//
//  Created by hitesh rakholiya on 07/01/17.
//  Copyright (c) 2017 hitesh rakholiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITextFieldDelegate>
{
    
}

@property (strong, nonatomic) IBOutlet UITextField *ID_TEXT;

@property (strong, nonatomic) IBOutlet UITextField *NAME_TEXT;

@property (strong, nonatomic) IBOutlet UITextField *DES_TEXT;

// Lable Outlets
@property (strong, nonatomic) IBOutlet UILabel *id_lbl;
@property (strong, nonatomic) IBOutlet UILabel *Name_lbl;
@property (strong, nonatomic) IBOutlet UILabel *Des_lbl;


// Click Events
- (IBAction)InsertClick:(id)sender;
- (IBAction)DeleteClick:(id)sender;
- (IBAction)Select_Click:(id)sender;

- (IBAction)Update_Click:(id)sender;

- (IBAction)Bulk_Insert_Click:(id)sender;

@end

