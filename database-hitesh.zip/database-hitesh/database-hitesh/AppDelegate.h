//
//  AppDelegate.h
//  database-hitesh
//
//  Created by hitesh rakholiya on 07/01/17.
//  Copyright (c) 2017 hitesh rakholiya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FMDatabase.h"
#import "FMDatabaseQueue.h"
#import "FMResultSet.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property(strong,nonatomic) FMDatabaseQueue *queue;
@property(strong,nonatomic)NSString *dbpath;

// For Bulk Insert Data
-(NSMutableArray*)Convert_Json_String_From_Arr:(NSString*)str;
-(NSString*)Convert_arr_From_Json_String:(NSMutableArray*)arr;




@end

