//
//  ViewController.h
//  video
//
//  Created by kavi gevariya on 24/06/17.
//  Copyright © 2017 kavi gevariya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVKit/AVKit.h>
#import <AVFoundation/AVFoundation.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <CoreMedia/CoreMedia.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <MediaPlayer/MediaPlayer.h>



@interface ViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate,MPMediaPickerControllerDelegate>
{
    IBOutlet UIActivityIndicatorView *ActivityView;
}




    @property(nonatomic,retain)AVAsset* firstAsset;
   // @property(nonatomic,retain)AVAsset* secondAsset;
    @property(nonatomic,retain)AVAsset* audioAsset;



- (BOOL) startMediaBrowserFromViewController: (UIViewController*) controller
                               usingDelegate: (id <UIImagePickerControllerDelegate,
                                               UINavigationControllerDelegate>) delegate;

- (void)exportDidFinish:(AVAssetExportSession*)session;

@end

