//
//  main.m
//  video
//
//  Created by kavi gevariya on 24/06/17.
//  Copyright © 2017 kavi gevariya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
