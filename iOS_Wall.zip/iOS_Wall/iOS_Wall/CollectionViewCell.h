//
//  CollectionViewCell.h
//  iOS_Wall
//
//  Created by kavi on 13/03/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionViewCell : UICollectionViewCell

@property (strong,nonatomic) IBOutlet UIImageView *img;

@end
