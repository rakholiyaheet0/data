//
//  ViewController.h
//  iOS_Wall
//
//  Created by kavi on 13/03/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UICollectionViewDelegate,UICollectionViewDataSource>
{
    IBOutlet UICollectionView *imgcollect;
}


@end

