//
//  CollectionViewCell.m
//  iOS_Wall
//
//  Created by kavi on 13/03/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import "CollectionViewCell.h"

@implementation CollectionViewCell

@end
