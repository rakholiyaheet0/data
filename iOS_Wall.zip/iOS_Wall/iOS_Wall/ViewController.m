//
//  ViewController.m
//  iOS_Wall
//
//  Created by kavi on 13/03/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import "ViewController.h"
#import "CollectionViewCell.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import <AssetsLibrary/AssetsLibrary.h>


@interface ViewController ()
{
    CollectionViewCell *cell;
    NSMutableArray *imgarr;
    
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.navigationItem setTitle:@"iOS_Wall."];
    
    imgarr = [[NSMutableArray alloc]initWithObjects:[UIImage imageNamed:@"1.jpg"],[UIImage imageNamed:@"2.png"],[UIImage imageNamed:@"3.jpg"],[UIImage imageNamed:@"4.jpg"],[UIImage imageNamed:@"5.jpg"],[UIImage imageNamed:@"6.jpg"],[UIImage imageNamed:@"7.jpg"],[UIImage imageNamed:@"8.jpg"],[UIImage imageNamed:@"9.jpg"],[UIImage imageNamed:@"10.jpg"],[UIImage imageNamed:@"11.jpg"],[UIImage imageNamed:@"12.jpg"],[UIImage imageNamed:@"13.jpg"],[UIImage imageNamed:@"14.jpg"],[UIImage imageNamed:@"15.jpg"],[UIImage imageNamed:@"16.jpg"],[UIImage imageNamed:@"17.png"],[UIImage imageNamed:@"18.jpg"], nil];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return imgarr.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath;
{
    cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    cell.layer.borderWidth=3;
    cell.layer.cornerRadius=5;
    cell.layer.borderColor=[UIColor blackColor].CGColor;
   
    cell.img.image =[imgarr objectAtIndex:indexPath.row];
    
    
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath;
{
    UIAlertController *alertaction=[UIAlertController alertControllerWithTitle:@"What you want to do." message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    
    [alertaction addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        
        // Cancel button tappped.
        [self dismissViewControllerAnimated:YES completion:^{
        }];
    }]];
    
    [alertaction addAction:[UIAlertAction actionWithTitle:@"Set as Wallpaper" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            UIImageWriteToSavedPhotosAlbum([imgarr objectAtIndex:indexPath.row], nil, nil, nil);
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Alert !!" message:@"Selected photo is saved successfully in PHOTO, now you can set that as a wallpaper." preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
                              {
                                  [self dismissViewControllerAnimated:YES completion:nil];
                                  
                              }]];
            
            [self presentViewController:alert animated:YES completion:nil];
        });
        
       
        
                [self dismissViewControllerAnimated:YES completion:^{
        }];
    }]];

     [self presentViewController:alertaction animated:YES completion:nil];

}

@end
