//
//  webserviceViewController.m
//  tableviewtask_custome_1
//
//  Created by hitesh rakholiya on 09/03/16.
//  Copyright (c) 2016 hitesh rakholiya. All rights reserved.
//

#import "webserviceViewController.h"
#import "RemoteImageView.h"

@interface webserviceViewController ()

@end

@implementation webserviceViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    url =[[NSURL alloc]initWithString:@"http://iglobsyn.com/rideup/index.php/Webservice/login?"];
    
    Data=[[NSMutableData alloc]init];
    
    NSString *Parameter=[NSString stringWithFormat:@"email=%@&password=%@&utid=%@&devicetoken=%@&urid=%@",@"samir.mansuri@iglobsyn.com",@"Samir@123",@"3",@"038652f7bc341a9a7f8eb1c518441ee63d8731b5da0cc1b85e0f068d3e5adcc1",@"3"];
    
    NSData *postData = [Parameter dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *postLength = [NSString stringWithFormat:@"%lu",(unsigned long)[postData length]];
    
    request=[[NSMutableURLRequest alloc]initWithURL:url];
    
    [request setHTTPMethod:@"POST"];
    
    [request setTimeoutInterval:60];
    
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    
    [request setHTTPBody:postData];
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)submit_click:(UIButton *)sender
{
    
    
    connection =[[NSURLConnection alloc]initWithRequest:request delegate:self];
    
    [connection start];
    
}

#pragma mark - NSURLConnection Delegate
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    
    UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"Connection Fail" message:@"Connection Fail Please Try Again" delegate:nil cancelButtonTitle:@"Cancel" otherButtonTitles:@"Ok", nil];
    [alt show];
    
    
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    
    [Data appendData:data];
    
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSError *err;
    
    
    NSDictionary *Response=[NSJSONSerialization JSONObjectWithData:Data options:NSJSONReadingMutableContainers error:&err];
    
    NSLog(@"%@",Response);
    
    NSString *status=[[Response valueForKey:@"response"] valueForKey:@"status"];
    
    if ([status isEqualToString:@"1"])
    {
        _message_lbl.text=[[[Response valueForKey:@"response"] valueForKey:@"data"]valueForKey:@"message"];
        
        _name_lbl.text=[[[Response valueForKey:@"response"] valueForKey:@"data"]valueForKey:@"name"];
        
        _ur_id.text=[[[Response valueForKey:@"response"] valueForKey:@"data"]valueForKey:@"urid"];
        
        _user_id.text=[[[Response valueForKey:@"response"] valueForKey:@"data"]valueForKey:@"userid"];
        
        __profile_image.imageURL=[NSURL URLWithString:[NSString stringWithFormat:@"%@",[[[Response valueForKey:@"response"] valueForKey:@"data"] valueForKey:@"image"]]];
        
    }
    else
    {
        UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"Login Fail" message:@"Login Fail Please Try Again" delegate:nil cancelButtonTitle:@"Cancel" otherButtonTitles:@"Ok", nil];
        [alt show];
    }
    
}




@end
