//
//  secondViewController.h
//  tableviewtask_custome_1
//
//  Created by hitesh rakholiya on 27/02/16.
//  Copyright (c) 2016 hitesh rakholiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface secondViewController : UIViewController
{
    IBOutlet UIImageView *imageview1;
    IBOutlet UIButton *loginbutton;
    
}

@property(strong,nonatomic)UIImage *imag;

@end
