//
//  loginwithinstagramViewController.m
//  tableviewtask_custome_1
//
//  Created by hitesh rakholiya on 29/02/16.
//  Copyright (c) 2016 hitesh rakholiya. All rights reserved.
//

#import "loginwithinstagramViewController.h"


@interface loginwithinstagramViewController ()

@end

@implementation loginwithinstagramViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

/*-(IBAction)next:(id)sender
{
    webserviceViewController *web=[[webserviceViewController alloc]initWithNibName:@"webserviceViewController" bundle:nil];
    [self.navigationController pushViewController:web animated:YES];
}
 */
@end
