//
//  ViewController.h
//  tableviewtask_custome_1
//
//  Created by hitesh rakholiya on 22/02/16.
//  Copyright (c) 2016 hitesh rakholiya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "firstViewController.h"
@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
   
}

@property(strong,nonatomic)UITableView *tab;

@property(strong,nonatomic)NSMutableArray *imgarr;
@property(strong,nonatomic) NSMutableArray *namearr;
@property(strong,nonatomic)NSMutableArray *descarr;
@property(strong,nonatomic) NSMutableArray *seev;
@property(strong,nonatomic)NSMutableArray *surnamearr;


@end

