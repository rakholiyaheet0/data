//
//  firstViewController.m
//  tableviewtask_custome_1
//
//  Created by hitesh rakholiya on 22/02/16.
//  Copyright (c) 2016 hitesh rakholiya. All rights reserved.
//

#import "firstViewController.h"
#import "secondViewController.h"
#import "webserviceViewController.h"


@interface firstViewController ()

@end

@implementation firstViewController
@synthesize img;
@synthesize namearr;
@synthesize imgarr;
@synthesize descarr;
@synthesize surnamearr;
@synthesize seev;
@synthesize gest;

- (void)viewDidLoad
{
    [super viewDidLoad];
    //tap gesture
    img.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(simpletap:)];
    tap.numberOfTapsRequired = 2;
    tap.numberOfTouchesRequired = 1;
    [img addGestureRecognizer:tap];
    
    //pinch
    UIPinchGestureRecognizer *pinch=[[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(pinchclick:)];
    [img addGestureRecognizer:pinch];
    
    
    
    img.image=[UIImage imageNamed:[imgarr objectAtIndex:[[seev objectAtIndex:0]integerValue]]];
    
    lblname.text=[namearr objectAtIndex:[[seev objectAtIndex:0]integerValue]];
    lblsurname.text=[surnamearr objectAtIndex:[[seev objectAtIndex:0]integerValue]];
    lbldesc.text=[descarr objectAtIndex:[[seev objectAtIndex:0]integerValue]];
    NSLog(@"%@",[descarr objectAtIndex:[[seev objectAtIndex:0]integerValue]]);
    
    
}
#pragma calculating the label height acco to content
- (CGFloat)heightForText:(NSString *)bodyText
{
    
    CGSize maxsize=CGSizeMake(lbldesc.frame.size.width-5,MAXFLOAT);
    CGRect labelSize = [lbldesc.text boundingRectWithSize:maxsize options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:lbldesc.font} context:nil];
    
    CGFloat height = labelSize.size.height;
    return height;
}

-(void)simpletap:(UIPanGestureRecognizer*)view
{
    secondViewController *s2=[[secondViewController alloc]initWithNibName:@"secondViewController" bundle:nil];
    
    s2.imag=img.image;
    
    [self presentViewController:s2 animated:YES completion:nil];
    
}

#pragma mark - Pinch Click

-(void)pinchclick:(UIPinchGestureRecognizer*)view
{
    view.view.transform = CGAffineTransformScale(view.view.transform,view.scale, view.scale);
    view.scale=1;
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}
//share image via gmail
#pragma mark - ShareImages Click

- (IBAction)share_images:(id)sender
{
    
    MFMailComposeViewController *mail=[[MFMailComposeViewController alloc]init];
    
    if ([MFMailComposeViewController canSendMail])
    {
        mail.mailComposeDelegate=self;
        NSArray *arr1=[[NSArray alloc]initWithObjects:@"rakholiyahitesh0@gmail.com", nil];
        [mail setCcRecipients:arr1];
        [mail setSubject:@"Resume"];
        [mail setBccRecipients:arr1];
        [mail setToRecipients:arr1];
        [mail setMessageBody:@"hellllo" isHTML:NO];
        
        NSString *path = [[NSBundle mainBundle] pathForResource:@"4" ofType:@"jpg"];
        NSData *myData = [NSData dataWithContentsOfFile:path];
        // [picker addAttachmentData:myData mimeType:@"image/jpeg" fileName:@"rainy"];
        [mail addAttachmentData:myData mimeType:@"image/jpg" fileName:@"4"];
        
    }
    
    [self presentViewController:mail animated:YES completion:nil];
    
    
}

- (IBAction)shareWithinstagram:(id)sender
{
    if ([[[UIDevice currentDevice] systemVersion] floatValue] < 5.0)
    {
        float i = [[[UIDevice currentDevice] systemVersion] floatValue];
        NSString *str = [NSString stringWithFormat:@"We're sorry, but Instagram is not supported with your iOS %.1f version.", i];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Message" message:str delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
    else
    {
        CGRect rect = CGRectMake(0 ,0 , 0, 0);
        NSString  *jpgPath = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/Test.ig"];
        
        NSURL *igImageHookFile = [[NSURL alloc] initWithString:[[NSString alloc] initWithFormat:@"file://%@", jpgPath]];
        NSLog(@"JPG path %@", jpgPath);
        NSLog(@"URL Path %@", igImageHookFile);
        self.docFile.UTI = @"com.instagram.photo";
        self.docFile = [self setupControllerWithURL:igImageHookFile usingDelegate:self];
        self.docFile=[UIDocumentInteractionController interactionControllerWithURL:igImageHookFile];
        [self.docFile presentOpenInMenuFromRect: rect    inView: self.view animated: YES ];
        NSURL *instagramURL = [NSURL URLWithString:@"instagram://media?id=MEDIA_ID"];
        if ([[UIApplication sharedApplication] canOpenURL:instagramURL]) {
            [self.docFile presentOpenInMenuFromRect: rect    inView: self.view animated: YES ];
        }
        else
        {
            NSLog(@"No Instagram Found");
        }
        
    }
    
}
- (UIDocumentInteractionController *) setupControllerWithURL: (NSURL*) fileURL usingDelegate: (id <UIDocumentInteractionControllerDelegate>) interactionDelegate {
    UIDocumentInteractionController *interactionController = [UIDocumentInteractionController interactionControllerWithURL: fileURL];
    interactionController.delegate = interactionDelegate;
    return interactionController;
}

- (void)documentInteractionControllerWillPresentOpenInMenu:(UIDocumentInteractionController *)controller
{
    
}
- (IBAction)postToFacebook:(id)sender

{
    if([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook])
    {
        
        SLComposeViewController *controller = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
        
        [controller setInitialText:@"First"];
        // [controller addURL:[NSURL URLWithString:@"http://www.facebook.com"]];
        //NSLog(@"%@",);
        [controller addImage:[UIImage imageNamed:@"2.jpg"]];
        
        [self presentViewController:controller animated:YES completion:Nil];
    }
    else
    {
        NSLog(@"not available");
    }
}
-(IBAction)next:(id)sender;
{
    webserviceViewController *web=[[webserviceViewController alloc]initWithNibName:@"webserviceViewController" bundle:nil];
    [self.navigationController pushViewController:web animated:YES];
}
@end