//
//  webserviceViewController.h
//  tableviewtask_custome_1
//
//  Created by hitesh rakholiya on 09/03/16.
//  Copyright (c) 2016 hitesh rakholiya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RemoteImageView.h"

@interface webserviceViewController : UIViewController<NSURLConnectionDataDelegate,NSURLConnectionDelegate>
{
    NSMutableURLRequest *request;
    NSURLConnection *connection;
    NSURL *url;
    NSMutableData *Data;
    
}
@property (strong, nonatomic) IBOutlet UILabel *name_lbl;
@property (strong, nonatomic) IBOutlet UILabel *message_lbl;
@property (strong, nonatomic) IBOutlet UILabel *user_id;
@property (strong, nonatomic) IBOutlet UILabel *ur_id;
@property (strong, nonatomic) IBOutlet RemoteImageView *_profile_image;

@end
