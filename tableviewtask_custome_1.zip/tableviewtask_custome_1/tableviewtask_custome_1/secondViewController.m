//
//  secondViewController.m
//  tableviewtask_custome_1
//
//  Created by hitesh rakholiya on 27/02/16.
//  Copyright (c) 2016 hitesh rakholiya. All rights reserved.
//

#import "secondViewController.h"
#import "loginwithinstagramViewController.h"

@interface secondViewController ()

@end

@implementation secondViewController
@synthesize imag;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //for present image
    
    imageview1.image=imag;
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)cancel_button:(id)sender
{
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}
- (IBAction)loginwithinstagram:(id)sender
{
    loginwithinstagramViewController *login=[[loginwithinstagramViewController alloc]initWithNibName:@"loginwithinstagramViewController" bundle:nil];
    [self.navigationController pushViewController:login animated:YES];
}

@end
