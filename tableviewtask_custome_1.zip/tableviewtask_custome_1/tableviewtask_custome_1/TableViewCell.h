//
//  TableViewCell.h
//  tableviewtask_custome_1
//
//  Created by hitesh rakholiya on 22/02/16.
//  Copyright (c) 2016 hitesh rakholiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *des;


@property (strong, nonatomic) IBOutlet UILabel *sur_nm;

@property (strong, nonatomic) IBOutlet UILabel *F_name;
@property (strong, nonatomic) IBOutlet UIImageView *img;

@end
