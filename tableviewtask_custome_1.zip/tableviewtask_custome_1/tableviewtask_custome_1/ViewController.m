//
//  ViewController.m
//  tableviewtask_custome_1
//
//  Created by hitesh rakholiya on 22/02/16.
//  Copyright (c) 2016 hitesh rakholiya. All rights reserved.
//

#import "ViewController.h"
#import "TableViewCell.h"

@interface ViewController ()
{
    TableViewCell * cell;
    firstViewController *FirstView;
    
}
@end

@implementation ViewController
@synthesize tab;
@synthesize imgarr;
@synthesize namearr;
@synthesize seev;
@synthesize surnamearr;
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    
    [self.tab registerNib:[UINib nibWithNibName:@"TableViewCell"bundle:nil] forCellReuseIdentifier:@"TableviewCell1"];
    //uses for set navigation bar
    
    self.navigationItem.title = @"Identity";
    
    imgarr=[[NSMutableArray alloc]initWithObjects:@"1.jpg",@"2.jpg",@"3..jpg",@"4.jpg",@"5.jpg",nil];
    
    namearr=[[NSMutableArray alloc]initWithObjects:@"hitesh",@"jignesh",@"sanket",@"rakesh",@"vikash",nil];
    surnamearr=[[NSMutableArray alloc]initWithObjects:@"babariya",@"radadiya",@"sharma",@"rakholiya",@"ramani",nil];
    
    
    _descarr=[[NSMutableArray alloc]initWithObjects:@"he is an ios developer and working with ios app developement and his date of birth 28-2-1991",@"he is an ios developer and working with ios app developement and his date of birth 28-2-1991",@"he is an ios developer at iglobsyn technologies.he has a one year of experience og ios app developement",@"he is an ios developer",@"he is an android developer",@"he is web developer at iglobsyn",nil];
}
-(void)viewWillAppear:(BOOL)animated
{
    FirstView=[[firstViewController alloc]initWithNibName:@"firstViewController" bundle:[NSBundle mainBundle]];
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return namearr.count;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    cell=[tab dequeueReusableCellWithIdentifier:@"TableviewCell1" forIndexPath:indexPath];
    
    cell.sur_nm.text=[surnamearr objectAtIndex:indexPath.row];
    
    cell.F_name.text=[namearr objectAtIndex:indexPath.row];
    
    cell.des.text=[_descarr objectAtIndex:indexPath.row];
    
    CGFloat h=[self heightForText:cell.des.text];
    
    [cell.des setFrame:CGRectMake(cell.des.frame.origin.x, cell.des.frame.origin.y, cell.des.frame.size.width, h)];
    
    cell.img.image=[UIImage imageNamed:[NSString stringWithFormat:@"%@",[imgarr objectAtIndex:indexPath.row]]];
    return cell;
    
}
- (CGFloat)heightForText2:(NSString *)bodyText
{
    
    CGSize maxsize=CGSizeMake(327,MAXFLOAT);
    
    CGRect cellSize = [cell.des.text boundingRectWithSize:maxsize options: NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:cell.des.font} context:nil];
    
    CGFloat height = cellSize.size.height;
    
    return height;
}
- (CGFloat)heightForText:(NSString *)bodyText
{
    
    CGSize maxsize=CGSizeMake(cell.des.frame.size.width-5,MAXFLOAT);
    
    CGRect cellSize = [cell.des.text boundingRectWithSize:maxsize options:
                        NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:cell.des.font} context:nil];
    
    CGFloat height = cellSize.size.height;
    
    return height;
    
}


/*- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
     cell=[tab dequeueReusableCellWithIdentifier:@"TableviewCell1" forIndexPath:indexPath];
    
    CGFloat cellsize=[self heightForText2:[_descarr objectAtIndex:indexPath.row]];
    
    return cellsize + 150;
    
}
 */
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 1;
    
}

#pragma mark - Did Select Event
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    /* FirstView.img.image=[UIImage imageNamed:[NSString stringWithFormat:@"%@",[imgarr objectAtIndex:indexPath.row]]];
     FirstView.surname=[namearr objectAtIndex:indexPath.row];
     FirstView.name=[namearr objectAtIndex:indexPath.row];
     FirstView.Des=[descarr objectAtIndex:indexPath.row];
     
     [self.navigationController pushViewController:FirstView animated:YES];
     
     NSString  *strval;
     strval=[NSString stringWithFormat:@"%d",indexPath.row];
     r1=[[NSArray alloc]initWithObjects:strval, nil];
     firstViewController.namearr=namearr;
     
     v2.r1=r1;
     [self.navigationController pushViewController:v2 animated:YES];
     */
    firstViewController *v2=[[firstViewController alloc]init];
    //v2.imgarr=self.imgarr;
    v2.imgarr=self.imgarr;
    v2.namearr=self.namearr;
    v2.descarr=self.descarr;
    v2.surnamearr=self.surnamearr;
    
    NSString *str1=[NSString stringWithFormat:@"%d",indexPath.row];
    seev=[[NSMutableArray alloc]initWithObjects:str1, nil];
    v2.seev=self.seev;
    [self.navigationController pushViewController:v2 animated:YES];
    
}


@end
