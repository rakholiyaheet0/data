//
//  ViewController.h
//  ContactsList
//
//  Created by ndot on 11/01/16.
//  Copyright © 2016 Ktr. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end

