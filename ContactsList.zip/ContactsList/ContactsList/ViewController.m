//
//  ViewController.m
//  ContactsList
//
//  Created by ndot on 11/01/16.
//  Copyright © 2016 Ktr. All rights reserved.
//

#import "ViewController.h"
#import "ContactList.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [[ContactList sharedContacts] fetchAllContacts]; //fetch all contacts by calling single to method
    
    if ([[ContactList sharedContacts]totalPhoneNumberArray].count !=0) {
        NSLog(@"Fetched Contact Details : %ld",[[ContactList sharedContacts]totalPhoneNumberArray].count);
    }
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



/*
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (NSClassFromString(@"CNContactStore")) {
        return [[ContactList sharedContacts]totalPhoneNumberArray].count;
    }else{
        return 1;
    }
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (NSClassFromString(@"CNContactStore")) {
        return [[[[[ContactList sharedContacts]totalPhoneNumberArray] objectAtIndex:section] valueForKey:@"phone"] count];
    }else{
        return [[[ContactList sharedContacts]totalPhoneNumberArray] count];
    }
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
 
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"" forIndexPath:indexPath];

    //In iOS 9 and above, use Contacts.framework
    if (NSClassFromString(@"CNContactStore")) { //if Contacts.framework is available
        cell.textLabel.text = [[[[ContactList sharedContacts]totalPhoneNumberArray] objectAtIndex:indexPath.section] valueForKey:@"name"];
    }else{
        cell.textLabel.text = [[[[ContactList sharedContacts]totalPhoneNumberArray] objectAtIndex:indexPath.row] valueForKey:@"name"];
    }
}
 */


@end
