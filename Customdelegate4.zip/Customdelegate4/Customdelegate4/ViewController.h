//
//  ViewController.h
//  Customdelegate4
//
//  Created by Hemant Gupta on 4/14/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController2.h"

@interface ViewController : UIViewController<cakedelegate>
{
    
}
@property(strong,nonatomic)IBOutlet UILabel *favourite_lbl;
@property(strong,nonatomic)IBOutlet UIButton *btn1;


@end

