//
//  ViewController2.m
//  Customdelegate4
//
//  Created by Hemant Gupta on 4/14/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import "ViewController2.h"
#import "ViewController.h"
@interface ViewController2 ()

@end

@implementation ViewController2
@synthesize arr2,textfield;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}
-(IBAction)backbtn:(id)sender;
{
    [[self delegate] sendtext:textfield.text];
    [self.navigationController popViewControllerAnimated:YES];
}

@end
