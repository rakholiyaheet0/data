//
//  ViewController2.h
//  Customdelegate4
//
//  Created by Hemant Gupta on 4/14/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ViewController2;
@protocol cakedelegate <NSObject>
-(void)sendtext:(NSString*)string;
@end
@interface ViewController2 : UIViewController
@property(strong,nonatomic)IBOutlet UIButton *btn2;
@property(strong,nonatomic)IBOutlet UITextField *textfield;
@property(strong,nonatomic)NSMutableArray *arr2;
@property(strong,nonatomic)id <cakedelegate>delegate;

@end
