//
//  ViewController.m
//  Customdelegate4
//
//  Created by Hemant Gupta on 4/14/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import "ViewController.h"
#import "ViewController2.h"

@interface ViewController ()<cakedelegate>
{
    
}

@end

@implementation ViewController
@synthesize favourite_lbl,btn1;

- (void)viewDidLoad {
    [super viewDidLoad];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}
-(IBAction)gobtn:(id)sender;
{
    ViewController2 *v2=[self.storyboard instantiateViewControllerWithIdentifier:@"ViewController2"];
    [self.navigationController pushViewController:v2 animated:YES];
    v2.delegate=self;
}
-(void)sendtext:(NSString *)string
{
    //[self.favourite_lbl setText:string];
    favourite_lbl.text=string;
}
@end
