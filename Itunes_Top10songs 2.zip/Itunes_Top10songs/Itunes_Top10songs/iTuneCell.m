//
//  iTuneCell.m
//  Itunes_Top10songs
//
//  Created by hitesh rakholiya on 25/03/16.
//  Copyright (c) 2016 hitesh rakholiya. All rights reserved.
//

#import "iTuneCell.h"

@implementation iTuneCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
