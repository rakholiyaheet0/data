//
//  iTuneCell.h
//  Itunes_Top10songs
//
//  Created by hitesh rakholiya on 25/03/16.
//  Copyright (c) 2016 hitesh rakholiya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RemoteImageView.h"

@interface iTuneCell : UITableViewCell

@property(strong,nonatomic)IBOutlet UILabel *lbl_author;
@property(strong,nonatomic)IBOutlet UILabel *lbl_im_name;
@property(strong,nonatomic)IBOutlet UILabel *lbl_rights;
@property(strong,nonatomic)IBOutlet UILabel *lbl_amount;
@property(strong,nonatomic)IBOutlet UILabel *lbl_artist;
@property (strong, nonatomic) IBOutlet RemoteImageView *img1;
@property(strong,nonatomic)IBOutlet UILabel *lbl_title;



@end
