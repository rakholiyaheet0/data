//
//  AppDelegate.h
//  Itunes_Top10songs
//
//  Created by hitesh rakholiya on 25/03/16.
//  Copyright (c) 2016 hitesh rakholiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

