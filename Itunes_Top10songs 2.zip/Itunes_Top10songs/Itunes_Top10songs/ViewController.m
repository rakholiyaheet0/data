//
//  ViewController.m
//  Itunes_Top10songs
//
//  Created by hitesh rakholiya on 25/03/16.
//  Copyright (c) 2016 hitesh rakholiya. All rights reserved.
//

#import "ViewController.h"
//#import "TableViewCell.h"
#import "RemoteImageView.h"

@interface ViewController ()
{
  //  TableViewCell *cell;
    NSArray *mainarr;
    NSArray *mainarr2;
   // NSArray *mainarr1;
    NSDictionary *Response;
}
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [tab registerNib:[UINib nibWithNibName:@"iTuneCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"cell"];

    [self retrieveddata];
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}
-(void)retrieveddata;
{
    url=[[NSURL alloc]initWithString:@"https://itunes.apple.com/us/rss/topaudiobooks/limit=10/json"];
    request=[NSURLRequest requestWithURL:url];
    Data=[[NSMutableData alloc]init];
    connection =[[NSURLConnection alloc]initWithRequest:request delegate:self];
    
   // [connection start];
  

    
    
}
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error;
{
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"failed" message:@"failed and try again" delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:@"ok",nil];
    [alert show];
}
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data;
{
    [Data appendData:data];
    //[connection start];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection;
{
    NSError *err;
    Response=[NSJSONSerialization JSONObjectWithData:Data options:NSJSONReadingMutableContainers error:&err];
    NSLog(@"%@::response",Response);
    mainarr=[[Response valueForKey:@"feed"]valueForKey:@"entry"];
    NSLog(@"mainarr::%@",mainarr);
    
    [tab reloadData];
    
    
   }
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return mainarr.count;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 305;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    cell=[tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    cell.lbl_author.text=[[[[Response valueForKey:@"feed"]valueForKey:@"author"]valueForKey:@"name"]valueForKey:@"label"];
    NSLog(@"label::%@::",[[[[Response valueForKey:@"feed"]valueForKey:@"author"]valueForKey:@"name"]valueForKey:@"label"]);

    cell.lbl_im_name.text=[[[mainarr objectAtIndex:indexPath.row]valueForKey:@"im:name"]valueForKey:@"label"];
    
    NSLog(@"im_name::%@",[[[mainarr objectAtIndex:indexPath.row]valueForKey:@"im:name"]valueForKey:@"label"]);
    
    cell.lbl_rights.text=[[[mainarr objectAtIndex:indexPath.row]valueForKey:@"rights"]valueForKey:@"label"];
    
    NSLog(@"rights::%@",[[[mainarr objectAtIndex:indexPath.row]valueForKey:@"rights"]valueForKey:@"label"]);
    
    cell.lbl_amount.text=[[[[mainarr objectAtIndex:indexPath.row]valueForKey:@"im:price"]valueForKey:@"attributes"]valueForKey:@"amount"];
    
    NSLog(@"amount::%@",[[[[mainarr objectAtIndex:indexPath.row]valueForKey:@"im:price"]valueForKey:@"attributes"]valueForKey:@"amount"]);
    
    cell.lbl_artist.text=[[[mainarr objectAtIndex:indexPath.row]valueForKey:@"im:artist"]valueForKey:@"label"];
    
    NSLog(@"artist::%@",[[[mainarr objectAtIndex:indexPath.row]valueForKey:@"im:artist"]valueForKey:@"label"]);
    
    cell.lbl_title.text=[[[mainarr objectAtIndex:indexPath.row]valueForKey:@"title"]valueForKey:@"label"];
    
    NSLog(@"title::%@",[[[mainarr objectAtIndex:indexPath.row]valueForKey:@"title"]valueForKey:@"label"]);
    
      cell.img1.imageURL=[NSURL URLWithString:[NSString stringWithFormat:@"%@",[[[[mainarr objectAtIndex:indexPath.row]valueForKey:@"im:image"]objectAtIndex:0]valueForKey:@"label"]]];
   
    
    
    return cell;
}
@end
