//
//  ViewController.h
//  Itunes_Top10songs
//
//  Created by hitesh rakholiya on 25/03/16.
//  Copyright (c) 2016 hitesh rakholiya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "iTuneCell.h"
@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,NSURLConnectionDataDelegate,NSURLConnectionDelegate>

{
    IBOutlet UITableView *tab;
    NSURL *url;
    NSURLConnection *connection;
    NSURLRequest *request;
    NSMutableData *Data;
    iTuneCell *cell;
}

@end

