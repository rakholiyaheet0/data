//
//  ViewController.m
//  latest-databasedemo
//
//  Created by hitesh rakholiya on 04/02/17.
//  Copyright (c) 2017 hitesh rakholiya. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSData* data;
    NSString* path;
    BOOL value;
    
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    imageview.layer.cornerRadius = imageview.frame.size.height/2;
    imageview.clipsToBounds = YES;
    //imageview.layer.cornerRadius = 86.f;
    imageview.layer.backgroundColor=[[UIColor clearColor] CGColor];
    imageview.layer.cornerRadius=60;
    imageview.layer.borderWidth=2.0;
    imageview.layer.masksToBounds = YES;
    imageview.layer.borderColor=[[UIColor blueColor] CGColor];
    NSString *docsDir;
    NSArray *dirPaths;
    
    //Get the directory
    dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    docsDir = dirPaths[0];
    
    //Build the path to keep the database
    _databasePath = [[NSString alloc] initWithString:[docsDir stringByAppendingPathComponent:@"my.db"]];
    
    NSFileManager *filemgr = [NSFileManager defaultManager];
    
    if([filemgr fileExistsAtPath:_databasePath] == NO){
        const char *dbpath = [_databasePath UTF8String];
        
        if(sqlite3_open(dbpath, &_DB) == SQLITE_OK){
            char *errorMessage;
            const char *sql_statement = "CREATE TABLE IF NOT EXISTS m (ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, ADDRESS TEXT, PHONE TEXT, LNAME TEXT, EMAILID TEXT, PASSWORD TEXT, GENDERSEG VALUE,IMAGE BLOB)";
            
            if(sqlite3_exec(_DB, sql_statement, NULL, NULL, &errorMessage) != SQLITE_OK){
                [self showUIAlertWithMessage:@"Failed to create the table" andTitle:@"Error"];
            }
            sqlite3_close(_DB);
        }
        else{
            [self showUIAlertWithMessage:@"Failed to open/create the table" andTitle:@"Error"];
        }
    }
}
- (IBAction)selectimage:(id)sender {
    
    UIImagePickerController *pickerController = [[UIImagePickerController alloc]
                                                 init];
    pickerController.delegate = self;
    [self presentViewController:pickerController animated:YES completion:nil];
}
- (void) imagePickerController:(UIImagePickerController *)picker
         didFinishPickingImage:(UIImage *)image
                   editingInfo:(NSDictionary *)editingInfo
{
    imageview.image = image;
    [self dismissModalViewControllerAnimated:YES];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
                                                         NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
     path = [documentsDirectory stringByAppendingPathComponent:
                      @"test.png" ];
    NSLog(@"%@",path);
    data = UIImagePNGRepresentation(image);
    NSLog(@"%@",data);
    [data writeToFile:path atomically:YES];
    btn_selectimage.hidden=YES;
}

-(void) showUIAlertWithMessage:(NSString*)message andTitle:(NSString*)title{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title
                                                    message:message
                                                   delegate:self
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
    
}

    // Do any additional setup after loading the view, typically from a nib.

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)save:(id)sender {
    NSString *val;
    if (_genderseg.selectedSegmentIndex==0)
    {
        val=@"M";
    }
    else if (_genderseg.selectedSegmentIndex==1)
    {
        val=@"F";
    }

    sqlite3_stmt *statement;
    const char *dbpath = [_databasePath UTF8String];
    
    if(sqlite3_open(dbpath, &_DB) == SQLITE_OK){
        NSString *insertSQL = [NSString stringWithFormat:@"INSERT INTO m (name, address, phone, lname, emailid, password, genderseg,image) VALUES (\"%@\", \"%@\", \"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")", _name.text, _address.text, _phone.text,_lname.text,_emailid.text,_password.text,val,imageview.image];
        sqlite3_bind_blob( statement, 1, [data bytes],(unsigned int) [data length], SQLITE_TRANSIENT);
        
        const char *insert_statement = [insertSQL UTF8String];
        sqlite3_prepare_v2(_DB, insert_statement, -1, &statement, NULL);
        
        if(sqlite3_step(statement) == SQLITE_DONE){
           // sqlite3_bind_blob(statement, 1, [data  bytes], [data length], SQLITE_TRANSIENT);
            [self showUIAlertWithMessage:@"User added to the database" andTitle:@"Message"];
            //imageview.image=nil;
            
            _name.text = @"";
            _address.text = @"";
            _phone.text = @"";
            _lname.text=@"";
            _emailid.text=@"";
            _password.text=@"";
            
        }
        else{
            [self showUIAlertWithMessage:@"Failed to add the user" andTitle:@"Error"];
        }
        sqlite3_finalize(statement);
        sqlite3_close(_DB);
    }
}


- (IBAction)find:(id)sender {
    sqlite3_stmt *statement;
    const char *dbpath = [_databasePath UTF8String];
    
    if(sqlite3_open(dbpath, &_DB) == SQLITE_OK){
        NSString *querySQL = [NSString stringWithFormat:@"SELECT address, phone, lname, emailid,password,genderseg,image FROM m WHERE name = \"%@\"", _name.text];
        const char *query_statement = [querySQL UTF8String];
        
        if(sqlite3_prepare_v2(_DB, query_statement, -1, &statement, NULL) == SQLITE_OK){
            if(sqlite3_step(statement) == SQLITE_ROW){
                NSString *addressField = [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 0)];
                _address.text = addressField;
                NSString *phoneField = [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 1)];
                _phone.text = phoneField;
                NSString *lname = [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 2)];
                _lname.text=lname;
                NSString *emailid = [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 3)];
                _emailid.text=emailid;
                NSString *password = [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 4)];
                _password.text=password;
                NSString *genderseg = [[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 5)];
              
                int blobBytesLength = sqlite3_column_bytes(statement, 1);
                NSData *blobData = [[NSData alloc]initWithBytes:sqlite3_column_blob(statement, 6)length:blobBytesLength];
                
                UIImage *imagetest = [[UIImage alloc] initWithData:blobData];
               
                imageview.image=imagetest;
                [self showUIAlertWithMessage:@"Match found in database" andTitle:@"Message"];
                
                
            }
            else{
                [self showUIAlertWithMessage:@"Match not found in databse" andTitle:@"Message"];
                _address.text = @"";
                _phone.text = @"";
                _lname.text=@"";
                _emailid.text=@"";
                _password.text=@"";
            }
            sqlite3_finalize(statement);
        }
        else{
            [self showUIAlertWithMessage:@"Failed to search the database" andTitle:@"Error"];
        }
        sqlite3_close(_DB);
    }
}

- (IBAction)remove:(id)sender {
    const char *dbpath = [_databasePath UTF8String];
    char *errorMessage;
    
    if(sqlite3_open(dbpath, &_DB) == SQLITE_OK){
        NSString *querySQL = [NSString stringWithFormat:@"DELETE FROM m WHERE name = \"%@\"", _name.text];
        const char *query_statement = [querySQL UTF8String];
        
        
        if(sqlite3_exec(_DB, query_statement, NULL, NULL, &errorMessage) == SQLITE_OK){
            [self showUIAlertWithMessage:@"Deleted from database" andTitle:@"Message"];
            _address.text = @"";
                _phone.text = @"";
                _lname.text=@"";
                _name.text=@"";
            _emailid.text=@"";
            _password.text=@"";
        }
        else{
            [self showUIAlertWithMessage:@"Failed to delete from database" andTitle:@"Error"];
        }
    }
    else{
        [self showUIAlertWithMessage:@"Failed to delete from database" andTitle:@"Error"];
    }
}

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch* touch = [[event allTouches] anyObject];
    if([_phone isFirstResponder] && [touch view] != _phone){
        [_phone resignFirstResponder];
    }
    [super touchesBegan:touches withEvent:event];
}
@end
