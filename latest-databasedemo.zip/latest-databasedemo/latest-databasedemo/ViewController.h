//
//  ViewController.h
//  latest-databasedemo
//
//  Created by hitesh rakholiya on 04/02/17.
//  Copyright (c) 2017 hitesh rakholiya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>

@interface ViewController : UIViewController<UIImagePickerControllerDelegate>
{
    IBOutlet UIImageView *imageview;
    IBOutlet UIButton *btn_selectimage;
}
@property (strong, nonatomic) NSString *databasePath;
@property (nonatomic) sqlite3 *DB;
@property (strong, nonatomic) IBOutlet UITextField *name;
@property (strong, nonatomic) IBOutlet UITextField *address;
@property (strong, nonatomic) IBOutlet UITextField *phone;
@property(strong,nonatomic)IBOutlet UITextField *lname;
@property(strong,nonatomic)IBOutlet UITextField *emailid;
@property(strong,nonatomic)IBOutlet UITextField *password;
@property(strong,nonatomic)IBOutlet UISegmentedControl *genderseg;
- (IBAction)save:(id)sender;
- (IBAction)find:(id)sender;
- (IBAction)remove:(id)sender;


@end

