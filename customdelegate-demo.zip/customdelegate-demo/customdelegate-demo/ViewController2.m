//
//  ViewController2.m
//  customdelegate-demo
//
//  Created by Hemant Gupta on 08/04/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import "ViewController2.h"

@interface ViewController2 ()
{
    NSMutableArray *arr_department;
}

@end

@implementation ViewController2

- (void)viewDidLoad {
    [super viewDidLoad];
    arr_department=[[NSMutableArray alloc]initWithObjects:@"hr",@"office",@"depar",@"fsdf",nil];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arr_department.count;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    cell.textLabel.text=[arr_department objectAtIndex:indexPath.row];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    [self.delegate didselect:self department:[tab cellForRowAtIndexPath:indexPath].textLabel.text];
    [self.navigationController popViewControllerAnimated:YES];
}
@end
