//
//  ViewController.m
//  customdelegate-demo
//
//  Created by Hemant Gupta on 08/04/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import "ViewController.h"
#import "ViewController2.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)clickedbtnnext:(id)sender
{
    ViewController2 *v2=[self.storyboard instantiateViewControllerWithIdentifier:@"ViewController2"];
    [self.navigationController pushViewController:v2 animated:YES];
    v2.delegate=self;
}
-(void)didselect:(ViewController2 *)controller department:(NSString *)depart
{
    [controller dismissViewControllerAnimated:YES completion:nil];
    _lbl_come.text=depart;
}
@end
