//
//  ViewController2.h
//  customdelegate-demo
//
//  Created by Hemant Gupta on 08/04/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ViewController2;

@protocol viewcontrollerdelegate <NSObject>

-(void)didselect:(ViewController2*)controller department:(NSString*)depart;

@end
@interface ViewController2 : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
   IBOutlet UITableView *tab;
}
@property(nonatomic,weak)id<viewcontrollerdelegate>delegate;
@end
