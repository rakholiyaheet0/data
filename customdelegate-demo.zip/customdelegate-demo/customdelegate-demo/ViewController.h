//
//  ViewController.h
//  customdelegate-demo
//
//  Created by Hemant Gupta on 08/04/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController2.h"

@interface ViewController : UIViewController<viewcontrollerdelegate>
{
    
}
@property(strong,nonatomic)IBOutlet UILabel *lbl_department;
@property(strong,nonatomic)IBOutlet UILabel *lbl_come;
@property(strong,nonatomic)IBOutlet UIButton *btn_next;

@end

