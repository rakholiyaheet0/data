//
//  ViewController3.h
//  entry table
//
//  Created by hitesh rakholiya on 17/02/17.
//  Copyright (c) 2017 hitesh rakholiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController3 : UIViewController<UITextFieldDelegate>
{
    IBOutlet UIButton *btn_login;
}
@property(strong,nonatomic)IBOutlet UITextField *email;
@property(strong,nonatomic)IBOutlet UITextField *pass;
@end
