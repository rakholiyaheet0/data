//
//  ViewController2.h
//  entry table
//
//  Created by hitesh rakholiya on 16/02/17.
//  Copyright (c) 2017 hitesh rakholiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController2 : UIViewController<UITextFieldDelegate,UIImagePickerControllerDelegate>
{
    
}
@property(strong,nonatomic)IBOutlet UITextField *txt_name;
@property(strong,nonatomic)IBOutlet UIImageView *imageview;
@property(strong,nonatomic)IBOutlet UITextField *txt_userid;
@property(strong,nonatomic)IBOutlet UITextField *txt_emailid;
@property(strong,nonatomic)IBOutlet UITextField *txt_password;
@property(strong,nonatomic)IBOutlet UITextField *txt_contactno;
@property(strong,nonatomic)IBOutlet UISegmentedControl *gender;

- (IBAction)InsertClick:(id)sender;
- (IBAction)DeleteClick:(id)sender;
//- (IBAction)Select_Click:(id)sender;

- (IBAction)Update_Click:(id)sender;


- (IBAction)Bulk_Insert_Click:(id)sender;
@property(strong,nonatomic)IBOutlet UILabel *lbl_name;
@property(strong,nonatomic)IBOutlet UILabel *lbl_userid;
@property(strong,nonatomic)IBOutlet UILabel *lbl_emailid;
@property(strong,nonatomic)IBOutlet UILabel *lbl_password;
@property(strong,nonatomic)IBOutlet UILabel *lbl_contactno;
//@property(strong,nonatomic)IBOutlet UILabel *lbl_name;

@end
