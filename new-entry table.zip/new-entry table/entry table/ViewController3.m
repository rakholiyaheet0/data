//
//  ViewController3.m
//  entry table
//
//  Created by hitesh rakholiya on 17/02/17.
//  Copyright (c) 2017 hitesh rakholiya. All rights reserved.
//

#import "ViewController3.h"
#import "Constant.h"
#import <sqlite3.h>
#import "FMDatabase.h"

@interface ViewController3 ()
{
   // NSString *emailstr;
    //NSString *passstr;
    NSString *str_email;
    NSString *str_pass;
}

@end

@implementation ViewController3

- (void)viewDidLoad {
    [super viewDidLoad];
    [APPDELEGATE.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
         
         FMResultSet *resultsWithCollegeName = [db executeQuery:@"SELECT * FROM jig"];
         
         while([resultsWithCollegeName next])
         {
             
            // _txt_userid.text=[NSString stringWithFormat:@"%d",[resultsWithCollegeName intForColumn:@"userid"]];
             
             str_email= [NSString stringWithFormat:@"%@",[resultsWithCollegeName stringForColumn:@"emailid"]];
             
            str_pass=[NSString stringWithFormat:@"%@",[resultsWithCollegeName stringForColumn:@"password"]];
//             _txt_contactno.text=[NSString stringWithFormat:@"%@",[resultsWithCollegeName stringForColumn:@"contactno"]];
//             _txt_name.text=[NSString stringWithFormat:@"%@",[resultsWithCollegeName stringForColumn:@"name"]];
//             
//             
//             ImageData=[resultsWithCollegeName dataForColumn:@"image"];
//             
//             NSLog(@"%lu",(unsigned long)ImageData.length);
//             _imageview.image=[UIImage imageWithData:ImageData];
//             
         }
     }];
    
    //[self clearalltextfields];

    //NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    
    // getting an NSString
//    emailstr = [prefs stringForKey:@"emailid"];
//    passstr=[prefs stringForKey:@"password"];
//    NSLog(@"%@",emailstr);
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}
-(IBAction)loginsr:(id)sender;
{
    NSString *em_str=[NSString stringWithFormat:@"%@",_email.text];
    NSString *pas_str=[NSString stringWithFormat:@"%@",_pass.text];
    if ([em_str isEqualToString:str_email] && [pas_str isEqualToString:str_pass]) {
        
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"sucess" message:@"login successful" delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil, nil];
        [alert show];
    }
    else
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"not" message:@"login not successful" delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil, nil];
        [alert show];
        
    }
}
@end
