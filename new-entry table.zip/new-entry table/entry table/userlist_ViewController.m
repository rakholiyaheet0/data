//
//  userlist_ViewController.m
//  entry table
//
//  Created by hitesh rakholiya on 19/02/17.
//  Copyright (c) 2017 hitesh rakholiya. All rights reserved.
//

#import "userlist_ViewController.h"
#import "Constant.h"
#import <sqlite3.h>
#import "FMDatabase.h"

@interface userlist_ViewController ()
{
    NSString *userid_str;
    NSString *email_styr;
    NSString *pass_str;
    NSString *contact_str;
    NSString *name_str;
    NSMutableArray *marr;
}

@end

@implementation userlist_ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [APPDELEGATE.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
         
         FMResultSet *resultsWithCollegeName = [db executeQuery:@"SELECT * FROM jig"];
         
         while([resultsWithCollegeName next])
         {
             
             userid_str=[NSString stringWithFormat:@"%d",[resultsWithCollegeName intForColumn:@"userid"]];
             
             email_styr= [NSString stringWithFormat:@"%@",[resultsWithCollegeName stringForColumn:@"emailid"]];
             
             pass_str=[NSString stringWithFormat:@"%@",[resultsWithCollegeName stringForColumn:@"password"]];
             contact_str=[NSString stringWithFormat:@"%@",[resultsWithCollegeName stringForColumn:@"contactno"]];
             name_str=[NSString stringWithFormat:@"%@",[resultsWithCollegeName stringForColumn:@"name"]];
             
             
            // ImageData=[resultsWithCollegeName dataForColumn:@"image"];
             
             //NSLog(@"%lu",(unsigned long)ImageData.length);
            // _imageview.image=[UIImage imageWithData:ImageData];
             
         }
     }];
    
    //[self clearalltextfields];
   marr=[[NSMutableArray alloc]initWithObjects:name_str,contact_str,pass_str,email_styr,userid_str, nil];

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return marr.count;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    cell.textLabel.text=[marr objectAtIndex:indexPath.row];
   // name_str=[NSString stringWithFormat:@"%@",[resultsWithCollegeName stringForColumn:@"name"]];

    
    return cell;
}
@end
