//
//  ViewController.m
//  FMDATABASE_DEMO
//
//  Created by Jignesh Radadiya on 6/22/15.
//  Copyright (c) 2015 Credencys. All rights reserved.
//

#import "ViewController.h"
#import <sqlite3.h>
#import "FMDatabase.h"
#import "AppDelegate.h"
#import "user_details.h"
@interface ViewController ()
{
    AppDelegate *appDel;
}
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    _salary_text.delegate=self;
    _dept_name_text.delegate=self;
    _id_text.delegate=self;
    _name_text.delegate=self;

    appDel=[[UIApplication sharedApplication]delegate];

    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)insert_click:(id)sender
{
    [self insertDataInDB];
}

- (IBAction)update_click:(id)sender
{
    [self updateDataInDB];
}

- (IBAction)delete_click:(id)sender
{
    [self deleteDataInDB];
}

- (IBAction)select_click:(id)sender
{
    [self getAllDataFromDB];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)insertDataInDB
{
   
       NSString *insertQuery = [NSString stringWithFormat:@"INSERT INTO INSIGHT_OPENION VALUES ('%d','%@','%@')",335,_name_text.text,_dept_name_text.text];
    
    [appDel.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
        [db executeUpdate:insertQuery];
    }];
    
    [self clearalltextfields];
        [self clearalllabel];
}


- (void)getAllDataFromDB
{
  
   user_details *selected_detail=[[user_details alloc]init];
    
    NSString *sqlSelectQuery =[NSString stringWithFormat:@"SELECT * FROM user_data where user_id=%ld",(long)_id_text.text.integerValue] ;
    
    [appDel.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
         
      FMResultSet *resultsWithCollegeName = [db executeQuery:sqlSelectQuery];
         
         while([resultsWithCollegeName next])
         {
             selected_detail.userid = [NSString stringWithFormat:@"%d",[resultsWithCollegeName intForColumn:@"user_id"]];
             
            selected_detail.userName = [NSString stringWithFormat:@"%@",[resultsWithCollegeName stringForColumn:@"user_nm"]];
             
             selected_detail.userdepartment = [NSString stringWithFormat:@"%@",[resultsWithCollegeName stringForColumn:@"dept_nm"]];
            
             selected_detail.usersalary = [NSString stringWithFormat:@"%@",[resultsWithCollegeName stringForColumn:@"salary"]];
             
             _id_lbl.text=selected_detail.userid;
             _name_lbl.text= selected_detail.userName;
              _dept_name_lbl.text=selected_detail.userdepartment;
             _salary_lbl.text=selected_detail.usersalary;
         }
     }];
    
    [self clearalltextfields];

}

- (void)updateDataInDB
{
   
    NSString *updateQuery = [NSString stringWithFormat:@"UPDATE user_data SET user_nm= '%@',dept_nm='%@',salary='%@'    WHERE user_id='%d'",_name_text.text,_dept_name_text.text,_salary_text.text,_id_text.text.intValue];
    [appDel.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
         
         [db executeUpdate:updateQuery];
     }];

    [self clearalltextfields];
        [self clearalllabel];
}
- (void)deleteDataInDB
{

    NSString *deleteQuery =[NSString stringWithFormat:@"DELETE FROM user_data WHERE user_id ='%d'",_id_text.text.intValue];
    
    [appDel.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
         [db executeUpdate:deleteQuery];
     }];
    
    [self clearalltextfields];
    [self clearalllabel];
}




-(void)clearalltextfields
{
    _id_text.text=nil;
    _name_text.text=nil;
    _dept_name_text.text=nil;
    _salary_text.text=nil;
}

-(void)clearalllabel
{
    _salary_lbl.text=nil;
    _name_lbl.text=nil;
    _id_lbl.text=nil;
    _dept_name_lbl.text=nil;
}
@end
