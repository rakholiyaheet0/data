//
//  user_details.m
//  FMDATABASE_DEMO
//
//  Created by Jignesh Radadiya on 6/22/15.
//  Copyright (c) 2015 Credencys. All rights reserved.
//

#import "user_details.h"

@implementation user_details
@synthesize userdepartment,userid,userName,usersalary;

-(id)initwithUSERID :(NSString *)strid USERNAME:(NSString *)strname USERDEPARTMENT: (NSString *)strdepartment USERSALARY:(NSString*)strsalary
{
    self.userid=strid;
    self.userName=strname;
    self.userdepartment=strdepartment;
    self.usersalary=strsalary;
    return self;
}

@end
