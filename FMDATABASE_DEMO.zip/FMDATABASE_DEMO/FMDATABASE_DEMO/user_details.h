//
//  user_details.h
//  FMDATABASE_DEMO
//
//  Created by Jignesh Radadiya on 6/22/15.
//  Copyright (c) 2015 Credencys. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface user_details : NSObject

@property (nonatomic,retain)NSString *userid;
@property (nonatomic,retain)NSString *userName;
@property (nonatomic,retain)NSString *userdepartment;
@property (nonatomic,retain)NSString *usersalary;


-(id)initwithUSERID :(NSString *)strid USERNAME:(NSString *)strname USERDEPARTMENT: (NSString *)strdepartment USERSALARY:(NSString*)strsalary;
@end
