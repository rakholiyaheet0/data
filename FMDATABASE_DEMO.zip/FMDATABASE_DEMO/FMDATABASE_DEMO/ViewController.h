//
//  ViewController.h
//  FMDATABASE_DEMO
//
//  Created by Jignesh Radadiya on 6/22/15.
//  Copyright (c) 2015 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UITextField *id_text;
@property (strong, nonatomic) IBOutlet UITextField *name_text;
@property (strong, nonatomic) IBOutlet UITextField *dept_name_text;
@property (strong, nonatomic) IBOutlet UITextField *salary_text;

- (IBAction)insert_click:(id)sender;
- (IBAction)update_click:(id)sender;
- (IBAction)delete_click:(id)sender;
- (IBAction)select_click:(id)sender;

@property (strong, nonatomic) IBOutlet UILabel *id_lbl;
@property (strong, nonatomic) IBOutlet UILabel *name_lbl;
@property (strong, nonatomic) IBOutlet UILabel *dept_name_lbl;
@property (strong, nonatomic) IBOutlet UILabel *salary_lbl;


@end

