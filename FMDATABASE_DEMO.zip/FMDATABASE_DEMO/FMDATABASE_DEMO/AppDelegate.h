//
//  AppDelegate.h
//  FMDATABASE_DEMO
//
//  Created by Jignesh Radadiya on 6/22/15.
//  Copyright (c) 2015 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FMDatabaseQueue.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property(strong,nonatomic)FMDatabaseQueue *queue;
@property(strong,nonatomic)NSString *dbpath;

@end

