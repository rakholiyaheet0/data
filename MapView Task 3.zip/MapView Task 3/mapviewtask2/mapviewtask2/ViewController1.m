//
//  ViewController1.m
//  mapviewtask2
//
//  Created by admin on 03/02/15.
//  Copyright (c) 2015 com.apps1. All rights reserved.
//

#import "ViewController1.h"

@interface ViewController1 ()

@end

@implementation ViewController1

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    spanx1=1.0;
    spany1=1.0;
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)locationclick:(id)sender
{
    map1.showsUserLocation=true;
    [map1 setCenterCoordinate:map1.userLocation.location.coordinate animated:YES];
    MKPointAnnotation *ann=[[MKPointAnnotation alloc]init];
    CLLocationCoordinate2D cord;
    cord.longitude=map1.userLocation.location.coordinate.longitude;
    cord.latitude=map1.userLocation.location.coordinate.latitude;
    ann.coordinate=cord;
    ann.title=map1.userLocation.title;
    ann.subtitle=map1.userLocation.title;
    [map1 addAnnotation:ann];
}

- (IBAction)changetype:(UISegmentedControl *)sender
{
    [map1 setMapType:seg1.selectedSegmentIndex];
}

- (IBAction)addpin:(id)sender
{
    
}

- (IBAction)zoominclick:(id)sender
{
   
    MKCoordinateRegion region;
    region.center.latitude = map1.userLocation.coordinate.latitude;
    region.center.longitude = map1.userLocation.coordinate.longitude;
    if (spanx1<=0.00 && spany1<=0.00)
    {
       UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"Zoom not possible" message:@"you have done maximum zoom" delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:@"ok", nil];
       [alt show];
    }
    
    else if (spanx1 >=0.00 && spany1>=0.00)
    {
       spanx1=spanx1-0.100;
       spany1=spany1-0.100;
        region.span.latitudeDelta = spanx1;
        region.span.longitudeDelta = spany1;
        [map1 setRegion:region animated:YES];
    }
    
}

- (IBAction)zoomoutclick:(id)sender
{
    
    MKCoordinateRegion region;
    region.center.latitude = map1.userLocation.coordinate.latitude;
   region.center.longitude = map1.userLocation.coordinate.longitude;
    if(spanx1<0.00 && spany1<0.00)
    {
        spany1=0.100;
        spanx1=0.100;
    }
    region.span.latitudeDelta = spanx1;
    region.span.longitudeDelta = spany1;
    spanx1=spanx1 + 1.0;
    spany1=spany1 + 1.0;
    
    
    //  self.searchButton.hidden = YES;
    [map1 setRegion:region animated:YES];
}

@end
