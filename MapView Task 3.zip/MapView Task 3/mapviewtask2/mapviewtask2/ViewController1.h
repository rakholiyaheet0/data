//
//  ViewController1.h
//  mapviewtask2
//
//  Created by admin on 03/02/15.
//  Copyright (c) 2015 com.apps1. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface ViewController1 : UIViewController<MKMapViewDelegate,UIAlertViewDelegate>
{
    IBOutlet MKMapView *map1;
    IBOutlet UISegmentedControl *seg1;
    float spanX;
    float spanY;
    float spanx1;
    float spany1;
}
- (IBAction)locationclick:(id)sender;
- (IBAction)changetype:(UISegmentedControl *)sender;
- (IBAction)addpin:(id)sender;
- (IBAction)zoominclick:(id)sender;
- (IBAction)zoomoutclick:(id)sender;
@end
