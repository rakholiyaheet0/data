//
//  ViewController.m
//  mapviewtask1
//
//  Created by admin on 03/02/15.
//  Copyright (c) 2015 com.apps1. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)locationclick:(id)sender
{
    map.showsUserLocation=true;
    [map setCenterCoordinate:map.userLocation.location.coordinate animated:YES];
    
}
- (IBAction)zoomToCurrentLocation:(UIButton *)sender
{
    //float spanX = 0.00725;
   // float spanY = 0.00725;
    MKCoordinateRegion region;
    region.center.latitude = map.userLocation.coordinate.latitude;
    region.center.longitude = map.userLocation.coordinate.longitude;
    //region.span.latitudeDelta = spanX;
    //region.span.longitudeDelta = spanY;
}
- (IBAction)typeclick:(id)sender
{
    [map setMapType:MKMapTypeHybrid];
}

- (IBAction)pinclick:(id)sender
{
    
  MKPointAnnotation  *ann1=[[MKPointAnnotation alloc]init];
    CLLocationCoordinate2D cord;
    cord.longitude=0.0;
    cord.latitude=0.0;
    ann1.coordinate =cord;
    ann1.title =@"Hello1";
    ann1.subtitle =@"Item1";
    
    MKPointAnnotation  *ann2=[[MKPointAnnotation alloc]init];
    CLLocationCoordinate2D cord2;
    cord2.longitude=1.0;
    cord2.latitude=2.0;
    ann2.coordinate =cord2;
    ann2.title =@"Hello2";
    ann2.subtitle =@"Item2";
    
   arr=[[NSArray alloc]initWithObjects:ann1,ann2, nil];
    [map addAnnotations:arr];
   
    //[map setCenterCoordinate:cord animated:YES];
    
}
-(void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    [map setCenterCoordinate:map.userLocation.location.coordinate animated:YES];
}
@end
