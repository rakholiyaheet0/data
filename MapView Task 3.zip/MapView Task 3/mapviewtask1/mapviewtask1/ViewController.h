//
//  ViewController.h
//  mapviewtask1
//
//  Created by admin on 03/02/15.
//  Copyright (c) 2015 com.apps1. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface ViewController : UIViewController<MKMapViewDelegate>
{
   IBOutlet MKMapView *map;
    NSArray *arr;
}
- (IBAction)locationclick:(id)sender;
- (IBAction)typeclick:(id)sender;
- (IBAction)pinclick:(id)sender;
- (IBAction)zoomToCurrentLocation:(UIButton *)sender;
@end
