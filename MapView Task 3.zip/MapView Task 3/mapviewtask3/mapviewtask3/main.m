//
//  main.m
//  mapviewtask3
//
//  Created by admin on 03/02/15.
//  Copyright (c) 2015 com.apps1. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
