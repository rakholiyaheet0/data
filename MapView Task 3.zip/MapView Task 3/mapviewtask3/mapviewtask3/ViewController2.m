//
//  ViewController2.m
//  mapviewtask3
//
//  Created by admin on 03/02/15.
//  Copyright (c) 2015 com.apps1. All rights reserved.
//

#import "ViewController2.h"
#import "ViewController3.h"
@interface ViewController2 ()

@end


@implementation ViewController2
//@synthesize arrindex;
@synthesize arr1;
//@synthesize dic1;
//@synthesize dic2;
//@synthesize dic3;
//@synthesize dic4;
//@synthesize dic5;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title=@"Address";
    // Do any additional setup after loading the view.
    NSLog(@"%@",arr1);
 // newarr=[[NSMutableArray alloc]initWithArray:[[arr objectAtIndex:0]allObjects]];
    //NSLog(@"%@",newarr);
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arr1.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell1=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell1"];
    cell1.textLabel.text=[arr1 objectAtIndex:indexPath.row];
    return cell1;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)clicktomapview:(id)sender
{
    ViewController3 *v3=[self.storyboard instantiateViewControllerWithIdentifier:@"ViewController3"];
    
    v3.mapdata=arr1;
    [self.navigationController pushViewController:v3 animated:YES];
    NSLog(@"map clicked");
}
@end
