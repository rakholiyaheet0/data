//
//  ViewController2.h
//  mapviewtask3
//
//  Created by admin on 03/02/15.
//  Copyright (c) 2015 com.apps1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController2 : UIViewController
{
    IBOutlet UITableView *table2;
    //NSMutableArray *newarr;
}
- (IBAction)clicktomapview:(id)sender;

@property (strong,nonatomic)NSMutableArray *arr1;
//@property (strong,nonatomic)NSArray *arrindex;
//@property (strong,nonatomic)NSMutableDictionary *dic1;
//@property (strong,nonatomic)NSMutableDictionary *dic2;
//@property (strong,nonatomic)NSMutableDictionary *dic3;
//@property (strong,nonatomic)NSMutableDictionary *dic4;
//@property (strong,nonatomic)NSMutableDictionary *dic5;

@end
