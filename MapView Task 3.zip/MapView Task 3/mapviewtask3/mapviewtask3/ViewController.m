//
//  ViewController.m
//  mapviewtask3
//
//  Created by admin on 03/02/15.
//  Copyright (c) 2015 com.apps1. All rights reserved.
//

#import "ViewController.h"
#import "ViewController2.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    dic1=[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"Atlanta, Georgia, USA", @"name",@"-84.38798199999999",@"longitude",@"33.748995",@"latitude",@"North America",@"continent", nil];
    
    dic2=[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"Baltimore, Maryland, USA", @"name",@"-76.612189",@"longitude",@"39.290385",@"latitude",@"North America",@"continent", nil];
    
    
    dic3=[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"Berlin, Germany", @"name",@"13.4114",@"longitude",@"52.523405",@"latitude",@"Europe",@"continent", nil];
    
    dic4=[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"Buenos Aires, Argentina", @"name",@"-58.381593",@"longitude",@"-734.603723",@"latitude",@"South America",@"continent", nil];

    dic5=[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"Boston, Massachusetts, USA", @"name",@"-71.0597732",@"longitude",@"42.3584308",@"latitude",@"North America",@"continent", nil];

    arr=[[NSMutableArray alloc]initWithObjects:dic1,dic2,dic3,dic4,dic5, nil];
    NSLog(@"%@",arr);
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arr.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    
    cell.textLabel.text=[[arr objectAtIndex:indexPath.row]
                         
                         
                         objectForKey:@"name"];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ViewController2 *v2 = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController2"];
    //NSString *str1=[NSString stringWithFormat:@"%d",indexPath.row];
    arrindex=[[NSMutableArray alloc]init];
    [arrindex addObjectsFromArray:[[arr objectAtIndex:indexPath.row] allObjects]];
    
    v2.arr1=arrindex;
   // v2.arrindex=arrindex;
//    v2.dic1=dic1;
//    v2.dic2=dic2;
//    v2.dic3=dic3;
//    v2.dic4=dic4;
//    v2.dic5=dic5;
    [self.navigationController pushViewController:v2 animated:YES];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
