//
//  ViewController3.m
//  mapviewtask3
//
//  Created by admin on 04/02/15.
//  Copyright (c) 2015 com.apps1. All rights reserved.
//

#import "ViewController3.h"

@interface ViewController3 ()

@end

@implementation ViewController3
@synthesize mapdata;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSLog(@"%@",mapdata);
    float log=[[mapdata objectAtIndex:1]floatValue];
    float lat=[[mapdata objectAtIndex:2]floatValue];
    map1.showsUserLocation=true;
    //[map1 setCenterCoordinate:map1.userLocation.location.coordinate animated:YES];
   
   ann=[[MKPointAnnotation alloc]init];
    CLLocationCoordinate2D cord;
    cord.longitude=log;
    cord.latitude=lat;
    ann.coordinate=cord;
    ann.title=[mapdata objectAtIndex:0];
    ann.subtitle=[mapdata objectAtIndex:3];
    [map1 addAnnotation:ann];
    [map1 setCenterCoordinate:cord animated:YES];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
