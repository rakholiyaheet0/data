//
//  AppDelegate.h
//  mapviewtask3
//
//  Created by admin on 03/02/15.
//  Copyright (c) 2015 com.apps1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
