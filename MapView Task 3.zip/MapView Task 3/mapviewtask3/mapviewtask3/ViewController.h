//
//  ViewController.h
//  mapviewtask3
//
//  Created by admin on 03/02/15.
//  Copyright (c) 2015 com.apps1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>
{
    IBOutlet UITableView *table1;
    NSMutableDictionary *dic1;
    NSMutableDictionary *dic2;
    NSMutableDictionary *dic3;
    NSMutableDictionary *dic4;
    NSMutableDictionary *dic5;
    NSMutableArray *arr;
    NSMutableArray *arrindex;
}
@end
