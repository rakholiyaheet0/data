//
//  ViewController3.h
//  mapviewtask3
//
//  Created by admin on 04/02/15.
//  Copyright (c) 2015 com.apps1. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
@interface ViewController3 : UIViewController<MKMapViewDelegate>
{
    IBOutlet MKMapView *map1;
    MKPointAnnotation *ann;
}
@property NSMutableArray *mapdata;

@end
