//
//  AppDelegate.h
//  video
//
//  Created by kavi gevariya on 24/06/17.
//  Copyright © 2017 kavi gevariya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

