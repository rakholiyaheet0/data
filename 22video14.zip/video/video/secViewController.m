//
//  secViewController.m
//  video
//
//  Created by kavi gevariya on 25/06/17.
//  Copyright © 2017 kavi gevariya. All rights reserved.
//

#import "secViewController.h"
#import <AVKit/AVKit.h>
#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>
//#import "AudioProcessor.h"
//#import "AudioProcessor.m"

@interface secViewController ()

{
    AVAudioPlayerNode *audioPlayer;
    
    AVAudioPlayerNode *audioFilePlayer;
    
    AVAudioPlayer *saveplayer;
    
    AVAudioRecorder *recorder;
    
    
    AVAudioEngine *audioEngine;
    AVAudioFile *audioFile;
   // ExtAudioFileRef *outref;
    AVAudioMixerNode *mixer;
    AVAudioUnitReverb *reverbNode;
    AVAudioSession *session;
    
    AVAudioSession *session2;
    
    NSURL *destinationURL;
    NSURL *soundFileURL;
    ExtAudioFileRef outFile;
    
   // BOOL volume;
    
   // NSMutableDictionary *recordSetting;
}

@end

@implementation secViewController
//@synthesize audioProcessor;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
//    if AVCaptureDevice.authorizationStatus(forMediaType: AVMediaTypeAudio) != .authorized {
//        AVCaptureDevice.requestAccess(forMediaType: AVMediaTypeAudio,
//                                      completionHandler: { (granted: Bool) in
//                                      })
//    }
//    
//    AVCaptureDevice.AVAuthorizationStatus
    
//    if ([AVCaptureDevice respondsToSelector:@selector(requestAccessForMediaType: completionHandler:)]) {
//        [AVCaptureDevice requestAccessForMediaType:AVMediaTypeAudio completionHandler:^(BOOL granted) {
//            // Will get here on both iOS 7 & 8 even though camera permissions weren't required
//            // until iOS 8. So for iOS 7 permission will always be granted.
//            if (granted) {
//                // Permission has been granted. Use dispatch_async for any UI updating
//                // code because this block may be executed in a thread.
//                
//            } else {
//                // Permission has been denied.
//            }
//        }];
//    }\
    
    
    audioEngine =[[AVAudioEngine alloc]init];
    audioFilePlayer=[[AVAudioPlayerNode alloc]init];
    mixer=[[AVAudioMixerNode alloc]init];
    
   
    [audioEngine attachNode:mixer];
    
   // [audioEngine attachNode:reverbNode];
    
   //
    
     [audioEngine attachNode:audioFilePlayer];
    
    
    
//    [reverbNode loadFactoryPreset:AVAudioUnitReverbPresetMediumHall];
//    reverbNode.wetDryMix=50.0f;
//    
//    [audioEngine connect:audioFilePlayer to:reverbNode format:audioFile.processingFormat];
//    [audioEngine connect:reverbNode to:audioEngine.mainMixerNode format:audioFile.processingFormat];
    
    
    
    
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

//#define DOCUMENTS_FOLDER [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]

- (IBAction)play:(id)sender {
    
   // [AudioProcessor start];
    
    session = [AVAudioSession sharedInstance];
    [session setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
    [session setActive:true error:nil];

    
    NSString *soundFilePath = [[NSBundle mainBundle] pathForResource:@"apple"  ofType:@"mp3"];
    
    soundFileURL = [NSURL fileURLWithPath:soundFilePath];
//
////    player = [[AVAudioPlayer alloc] initWithContentsOfURL:soundFileURL error:nil];
////    player.numberOfLoops = -1; //Infinite
////    
////    [player play];
//    
    
    audioFile = [[AVAudioFile alloc]initForReading: soundFileURL error:nil];
    
    AVAudioFormat *format =[[AVAudioFormat alloc]initWithCommonFormat:AVAudioPCMFormatInt16 sampleRate:44100.0 channels:1 interleaved:true];
    [audioEngine connect:audioEngine.inputNode to:mixer format:format];
    [audioEngine connect:audioFilePlayer to:mixer format:audioFile.processingFormat];
    [audioEngine connect:mixer to:audioEngine.mainMixerNode format:format];
    
   
//
    AVAudioFrameCount *count = (AVAudioFrameCount)audioFile.length;
   AVAudioFramePosition *position = (AVAudioFramePosition) 0;
//
    audioFilePlayer.volume=0.5;

    
    
    [audioFilePlayer scheduleSegment:audioFile startingFrame:position frameCount:count atTime:nil completionHandler:nil];
//    
    NSArray *paths2 = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
   NSString *documentsDirectory = [paths2 objectAtIndex:0];
    NSString *myPathDocs =  [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"/temp.wav" ]];
    
    destinationURL = [NSURL URLWithString:myPathDocs];
    
//
  
    //outref=nil;
  //  AVAudioFormat *format2= format.streamDescription;
  //  ExtAudioFileRef outputfile =nil;

//
    ExtAudioFileCreateWithURL((__bridge CFURLRef)destinationURL, kAudioFileWAVEType, format.streamDescription, NULL, kAudioFileFlags_EraseFile, &outFile);
    
//
   // [mixer installTapOnBus:0 bufferSize:  format:<#(AVAudioFormat * _Nullable)#> block:<#^(AVAudioPCMBuffer * _Nonnull buffer, AVAudioTime * _Nonnull when)tapBlock#>];
//
   // AVAudioPCMBuffer *buffer = [[AVAudioPCMBuffer alloc]init];
   // AVAudioTime *time =[[AVAudioTime alloc]init];
    
    
   // [mixer installTapOnBus:0 bufferSize:(AVAudioFrameCount)format.sampleRate *0.4 format:format block:{(buffer,time) }];
    
    [mixer installTapOnBus: 0 bufferSize: 8192 format: format block: ^(AVAudioPCMBuffer *buf, AVAudioTime *when) {
        // ‘buf' contains audio captured from input node at time 'when'
        
        AVAudioPCMBuffer *buffer =buf;
        
    
       ExtAudioFileWrite(outFile, buf.frameLength, buffer.audioBufferList);
        
      
        
    }];
    
    [audioEngine prepare];
    [audioEngine startAndReturnError:nil];
    
    [audioFilePlayer play];
    //[audioEngine isRunning];
//    [audioFilePlayer scheduleFile:audioFile atTime:nil completionHandler:nil];
//    
    
    
    
}

//func completion() {
//    
//    if self.isRec {
//        DispatchQueue.main.async {
//            self.rec(UIButton())
//        }
//    } else if self.isPlay {
//        DispatchQueue.main.async {
//            self.play(UIButton())
//        }
//    }
//}
//
//- (void) completion
//{
//    
//}

- (IBAction)stop:(id)sender {
    
    [audioEngine stop];
    [audioFilePlayer stop];
    [mixer removeTapOnBus:0];
    ExtAudioFileDispose(outFile);
    
    [session setActive:false error:nil];

    

}

-(void)audioRecorderDidFinishRecording:(AVAudioRecorder *)recorder successfully:(BOOL)flag
{
    NSLog(@"Done");
}

- (IBAction)saveplay:(id)sender {
    
    session2 = [AVAudioSession sharedInstance];
    [session2 setCategory:AVAudioSessionCategoryPlayback error:nil];
    [session2 setActive:true error:nil];
    
   // audioFile = [[AVAudioFile alloc]initForReading:destinationURL  error:nil];
    
    
    saveplayer = [[AVAudioPlayer alloc] initWithContentsOfURL:destinationURL error:nil];
     saveplayer.numberOfLoops = -1; //Infinite
    saveplayer.volume=0.8;
    [saveplayer play];

    
  //  self.audioEngine.connect(self.audioFilePlayer, to: self.audioEngine.mainMixerNode, format: audioFile.processingFormat)

//    [audioEngine connect:audioFilePlayer to:audioEngine.mainMixerNode format:audioFile.processingFormat];
//    
//    AVAudioFrameCount *count = (AVAudioFrameCount)audioFile.length;
//    AVAudioFramePosition *position = (AVAudioFramePosition) 0;
//    
////    if (volume==false) {
////        
////    
////    audioFilePlayer.volume=0.8;
////    }
////    
//    
//    [audioFilePlayer scheduleSegment:audioFile startingFrame:position frameCount:count atTime:nil completionHandler:nil];
//    
//    [audioEngine prepare];
//    [audioEngine startAndReturnError:nil];
//    [audioFilePlayer play];
}



@end
