//
//  secViewController.h
//  video
//
//  Created by kavi gevariya on 25/06/17.
//  Copyright © 2017 kavi gevariya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
//@class AudioProcessor;


@interface secViewController : UIViewController<AVAudioRecorderDelegate,AVAudioSessionDelegate>
//@property (retain, nonatomic) AudioProcessor *audioProcessor;
//
@end
