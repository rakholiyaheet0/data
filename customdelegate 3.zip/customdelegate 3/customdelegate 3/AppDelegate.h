//
//  AppDelegate.h
//  customdelegate 3
//
//  Created by Hemant Gupta on 4/14/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

