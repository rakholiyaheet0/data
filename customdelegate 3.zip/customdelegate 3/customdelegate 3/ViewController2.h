//
//  ViewController2.h
//  customdelegate 3
//
//  Created by Hemant Gupta on 4/14/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ViewController2;
@protocol customdelegate <NSObject>

-(void)getfirstname:(NSString*)string1;
-(void)getlastname:(NSString*)string2;


@end
@interface ViewController2 : UIViewController
{
    
}
@property(strong,nonatomic)IBOutlet UITextField *text11;
@property(strong,nonatomic)IBOutlet UITextField *text22;
@property(strong,nonatomic)IBOutlet UIButton *btn_back;
@property(strong,nonatomic)id <customdelegate>delegate;
@property(strong,nonatomic)NSString *secondstr1;
@property(strong,nonatomic)NSString *secondstr2;

@end
