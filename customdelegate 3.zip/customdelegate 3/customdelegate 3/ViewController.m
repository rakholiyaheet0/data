//
//  ViewController.m
//  customdelegate 3
//
//  Created by Hemant Gupta on 4/14/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import "ViewController.h"
#import "ViewController2.h"

@interface ViewController ()<customdelegate>

@end

@implementation ViewController
@synthesize txt1,txt2,lbl;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

-(IBAction)sendbtn:(id)sender;
{
    ViewController2 *v2=[self.storyboard instantiateViewControllerWithIdentifier:@"ViewController2"];
    //NSMutableArray *arr1=[[NSMutableArray alloc]init];
    NSString *strarr1=[NSString stringWithFormat:@"%@",txt1.text];
    NSString *strarr2=[NSString stringWithFormat:@"%@",txt2.text];
    v2.secondstr1=strarr1;
    v2.secondstr2=strarr2;
    [self.navigationController pushViewController:v2 animated:YES];
   // [self.navigationController presentViewController:v2 animated:YES completion:nil];
    txt1.text=nil;
    txt2.text=nil;
    v2.delegate=self;
    
}
-(void)getfirstname:(NSString *)string1
{
    txt1.text=string1;
    
}
-(void)getlastname:(NSString *)string2
{
    txt2.text=string2;
    lbl.text=string2;
}
@end
