//
//  ViewController2.m
//  customdelegate 3
//
//  Created by Hemant Gupta on 4/14/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import "ViewController2.h"
#import "ViewController.h"

@interface ViewController2 ()

@end

@implementation ViewController2
@synthesize secondstr1,secondstr2;

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%@",secondstr1);
    NSLog(@"%@",secondstr2);
    _text11.text=secondstr1;
    _text22.text=secondstr2;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}
-(IBAction)backbtn:(id)sender;
{
    [[self delegate] getfirstname:_text11.text];
    [[self delegate]getlastname:_text22.text];
    [self.navigationController popViewControllerAnimated:YES];
    self.delegate=self;
}
@end
