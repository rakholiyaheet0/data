//
//  ViewController.h
//  customdelegate 3
//
//  Created by Hemant Gupta on 4/14/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
#import "ViewController2.h"

@interface ViewController : UIViewController<customdelegate>
{
    
}
@property(strong,nonatomic)IBOutlet UITextField *txt1;
@property(strong,nonatomic)IBOutlet UITextField *txt2;
@property(strong,nonatomic)IBOutlet UIButton *btn_send;
@property(strong,nonatomic)IBOutlet UILabel *lbl;
@end

