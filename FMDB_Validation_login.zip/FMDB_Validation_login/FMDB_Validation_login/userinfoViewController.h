//
//  userinfoViewController.h
//  FMDB_Validation_login
//
//  Created by kavi on 15/02/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface userinfoViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    IBOutlet UITableView *usertable;
}


//@property (strong,nonatomic) IBOutlet UIBarButtonItem *delet_btn;
//- (IBAction)deleteinfo:(id)sender;


@end
