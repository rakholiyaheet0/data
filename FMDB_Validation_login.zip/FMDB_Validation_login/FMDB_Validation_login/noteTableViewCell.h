//
//  noteTableViewCell.h
//  FMDB_Validation_login
//
//  Created by kavi on 16/02/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface noteTableViewCell : UITableViewCell



@property (strong,nonatomic) IBOutlet UITextView *notetxtview;
@end
