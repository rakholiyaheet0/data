//
//  userinfoViewController.m
//  FMDB_Validation_login
//
//  Created by kavi on 15/02/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import "userinfoViewController.h"
#import "userTableViewCell.h"
#import "FMDatabase.h"
#import "FMDB.h"
#import "FMResultSet.h"
#import <sqlite3.h>

@interface userinfoViewController ()

{
    userTableViewCell *cell;
    NSMutableDictionary *dict;
    FMDatabase *db;
    
    NSString *passwordst;
    NSData *datauser;
    NSMutableArray *userarr, *arr4;
    
}

@end

@implementation userinfoViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.navigationItem setTitle:@"UserInfo"];
    
    
       userarr=[[NSMutableArray alloc]init];;
         arr4=[[NSMutableArray alloc]init];
 
    NSString *documentsDirectory = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *filePath=[NSString stringWithFormat:@"%@/%@",documentsDirectory,@"userInfo.sqlite"];
    NSLog(@"%@",filePath);
    db = [FMDatabase databaseWithPath:filePath];
    
    
    

    [db open];
    
    
    
    FMResultSet *resultsWithCollegeName = [db executeQuery:@"SELECT * FROM userData1"];
    
    while  ([resultsWithCollegeName next])
    {

//        
        NSString *enrolluser=[resultsWithCollegeName stringForColumn:@"enroll"];
       NSString *genderuser=[resultsWithCollegeName stringForColumn:@"gender"];
        NSString *nameuser=[resultsWithCollegeName stringForColumn:@"name"];
        NSString *emailuser=[resultsWithCollegeName stringForColumn:@"email"];
       NSString *contactuser=[resultsWithCollegeName stringForColumn:@"contact"];
        datauser=[resultsWithCollegeName dataForColumn:@"image"];
        passwordst=[resultsWithCollegeName stringForColumn:@"password"];
     //   dict= @{@"enrolluser":enrolluser,@"genderuser": genderuser,@"nameuser":nameuser,@"emailuser":emailuser,@"contactuser":contactuser};
              
//
        dict = [[NSMutableDictionary alloc]init];
        [dict setObject:enrolluser forKey:@"enroll"];
        [dict setObject:genderuser forKey:@"gender"];
       [dict setObject:nameuser forKey:@"name"];
        [dict setObject:emailuser forKey:@"email"];
        [dict setObject:contactuser forKey:@"contact"];
        [dict setObject:datauser forKey:@"data"];
        [dict setObject:passwordst forKey:@"password"];
        [userarr addObject:dict];
        
        
        //NSLog(@"dict data %@",dict);

        
//            NSString *st =[resultsWithCollegeName stringForColumn:@"gender"];
       // [userarr addObject:dict];
      //  NSData *bcdata=[resultsWithCollegeName dataForColumn:@"image"];
       // NSLog(@"%@",dict);
        
       // UIImage *imgbc=[UIImage imageWithData:bcdata];
      //  NSLog(@"img %@",st);
        
    }
    
    [usertable reloadData];

        NSLog(@"error");
        

    
    [db close];

    [usertable reloadData];

    //[self.navigationController setNavigationBarHidden:YES animated:YES];
    // Do any additional setup after loading the view.
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView;
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return userarr.count;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
     cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    cell.enroll_lbl.text=[userarr [indexPath.row] valueForKey:@"enroll" ];
    cell.gender_lbl.text=[userarr [indexPath.row] valueForKey:@"gender"];
    cell.name_lbl.text=[userarr [indexPath.row] valueForKey:@"name"];
    cell.email_lbl.text=[userarr [indexPath.row] valueForKey:@"email"];
    cell.contact_lbl.text=[userarr [indexPath.row] valueForKey:@"contact"];
    cell.proimg_lbl.image=[UIImage imageWithData:[userarr [indexPath.row] valueForKey:@"data"]];
    return cell;
}
//- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
//{
//    
//  //  NSString *state = [userarr [indexPath.row] valueForKey:@"enroll"];
//    NSString *state=[NSString stringWithFormat:@"%@",[usertable indexPathForSelectedRow]];
//    
//    
//    [tableView deselectRowAtIndexPath:[tableView indexPathForSelectedRow] animated:NO];
//    cell = [tableView cellForRowAtIndexPath:indexPath];
//    
//    //NSIndexPath *state = [tableView indexPathForSelectedRow];
//    
//    if (cell.accessoryType == UITableViewCellAccessoryNone) {
//        cell.accessoryType = UITableViewCellAccessoryCheckmark;
//    //    kavi=true;
//        [arr4 addObject:state];
//        
//       NSLog(@"%@",arr4);
//    
//        
//        // Reflect selection in data model
//    } else if (cell.accessoryType == UITableViewCellAccessoryCheckmark) {
//        cell.accessoryType = UITableViewCellAccessoryNone;
//      //  kavi=false;
//        [arr4 removeObject:state];
//        // Reflect deselection in data model
//    }
//    
//    NSLog(@"%@",arr4);
//    
//}
//- (IBAction)deleteinfo:(id)sender {
//    
//    
//}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
//    if (usertable.indexPathForSelectedRow == 0)
//        
//    {
//        editingStyle=UITableViewCellEditingStyleNone;
//    }
//
//    else
//    {
        
    
    if (editingStyle==UITableViewCellEditingStyleDelete )
        
    {
        UIAlertController * alertController = [UIAlertController alertControllerWithTitle: @"Delete User" message: @"Login first with valid cradential." preferredStyle:UIAlertControllerStyleAlert];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            NSString *usermatch=[NSString stringWithFormat:@"%@",[userarr [indexPath.row] valueForKey:@"email"]];

            textField.placeholder = @"User ID";
                textField.textAlignment=NSTextAlignmentCenter;
            textField.text=usermatch;
                    textField.textColor = [UIColor blueColor];
            textField.enabled=false;
                   // textField.clearButtonMode = UITextFieldViewModeWhileEditing;
                    textField.borderStyle = UITextBorderStyleRoundedRect;
                    textField.layer.cornerRadius=5;
                    textField.layer.masksToBounds=YES;
        }];

         [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.placeholder = @"Password";
            textField.textAlignment=NSTextAlignmentCenter;
            textField.textColor = [UIColor blueColor];
            textField.secureTextEntry=YES;
            textField.clearButtonMode = UITextFieldViewModeWhileEditing;
            textField.borderStyle = UITextBorderStyleRoundedRect;
            textField.layer.cornerRadius=5;
            textField.layer.masksToBounds=YES;
        }];

        [alertController addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
        {
            [self dismissViewControllerAnimated:alertController completion:nil];
        }]];

        
        [alertController addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
        {
        
                    NSArray * textfields = alertController.textFields;
                    UITextField * namefield = textfields[0];
                    UITextField *passfield = textfields [1];
                   // UITextField * passwordfiled = textfields[1];
                   // NSLog(@"%@:%@",namefield.text,passwordfiled.text);
            
            
            NSString *passmatch=[NSString stringWithFormat:@"%@",[userarr [indexPath.row] valueForKey:@"password"]];
            
            //namefield.text = usermatch;

    if ([passfield.text isEqualToString:passmatch])
    {
        
        NSLog(@"value of dict %@",[dict valueForKey:@"enroll"]);
        
                       // [userarr removeObjectAtIndex:indexPath.row];
                        
                        NSString *documentsDirectory = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
                        NSString *filePath=[NSString stringWithFormat:@"%@/%@",documentsDirectory,@"userInfo.sqlite"];
                        NSLog(@"%@",filePath);
                        db = [FMDatabase databaseWithPath:filePath];
                        
                        
                        if (![db open])
                        {
                            return;
                        }
                        [db open];
                        // NSString *deleteQuery = [NSString stringWithFormat:
                        // @"DELETE FROM kavish WHERE name='%@' and gender='%@' and id='%@' and image='%@'",_name_txt.text,_gender_txt.text,_id_txt.text, path];
                        [db executeUpdate:@"DELETE FROM userData1 WHERE enroll= (?) and gender= (?) and name = (?) and email = (?) and contact= (?) and password=(?) and image= (?)" ,[userarr [indexPath.row] valueForKey:@"enroll"],[userarr [indexPath.row] valueForKey:@"gender"],[userarr [indexPath.row] valueForKey:@"name"],[userarr [indexPath.row] valueForKey:@"email"],[userarr [indexPath.row] valueForKey:@"contact"],[userarr [indexPath.row] valueForKey:@"password"],[userarr [indexPath.row] valueForKey:@"data"]];
        
       // [userarr removeAllObjects];
       // [dict removeAllObjects];
        [userarr removeObjectAtIndex:indexPath.row];
        [usertable reloadData];
                        
                        [db close];
                        
        
        
                          //[usertable reloadData];
                        
                        
        return;
        
                    }
    
    
        
                    else
                    {
                        
            UIAlertController * alertController1 = [UIAlertController alertControllerWithTitle: @"Caution.." message: @"Login failed, please try again later." preferredStyle:UIAlertControllerStyleAlert];
            
                         [alertController1 addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                             {
                                  [self dismissViewControllerAnimated:alertController1 completion:nil];
            
                                 [self presentViewController:alertController animated:YES completion:nil];
            
                                 
                             }
                             
                            }]];
                        
        
                        
                        [self presentViewController:alertController1 animated:YES completion:nil];
                    }
//
               }]];

            [self presentViewController:alertController animated:YES completion:nil];
    
    }
    
   }


@end
