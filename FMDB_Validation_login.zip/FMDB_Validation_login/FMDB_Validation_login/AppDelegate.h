//
//  AppDelegate.h
//  FMDB_Validation_login
//
//  Created by kavi on 14/02/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>
#import "FMDB.h"
#import "FMDatabase.h"
#import "FMResultSet.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong,nonatomic) FMDatabase *db;


@end

