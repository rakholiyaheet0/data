//
//  userloginViewController.h
//  FMDB_Validation_login
//
//  Created by kavi on 16/02/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface userloginViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    IBOutlet UITableView *notetable;
}

@property (strong,nonatomic) IBOutlet UIBarButtonItem *signout_btn;
- (IBAction)signout:(id)sender;

@property (strong, nonatomic) IBOutlet UIBarButtonItem *usermenu_btn;

@property (strong,nonatomic) IBOutlet UIBarButtonItem *addnote_btn;

@property (strong, nonatomic) IBOutlet UIBarButtonItem *deletuserinfo;



@property (strong,nonatomic) IBOutlet UIImageView *proimg_lbl;

@property (strong,nonatomic) IBOutlet UILabel *name_lbl;
@property (strong,nonatomic) IBOutlet UILabel *email_lbl;
@property (strong,nonatomic) IBOutlet UILabel *contact_lbl;
@property (strong,nonatomic) IBOutlet UILabel *gender_lbl;
@property (strong,nonatomic) IBOutlet UILabel *password_lbl;


@end
