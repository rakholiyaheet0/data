//
//  userloginViewController.m
//  FMDB_Validation_login
//
//  Created by kavi on 16/02/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import "userloginViewController.h"
#import "ViewController.h"
#import "FMDB.h"
#import "FMDatabase.h"
#import "FMResultSet.h"
#import <sqlite3.h>
#import "noteTableViewCell.h"

@interface userloginViewController ()
{
    FMDatabase *db;
    
    NSString *enrolluser, *genderuser, *nameuser, *emailuser, *contactuser, *passworduser;
    NSData *datauser;
    
    noteTableViewCell *cell;
    
}

@end

@implementation userloginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.navigationItem setTitle:@"HOME"];
   [self.navigationItem setHidesBackButton:YES];
    self.signout_btn.enabled=false;
    self.addnote_btn.enabled=false;
    self.deletuserinfo.enabled=false;
    self.usermenu_btn.enabled=false;
   
    _proimg_lbl.image=nil;
    _name_lbl.text=nil;
    _email_lbl.text=nil;
    _contact_lbl.text=nil;
    _gender_lbl.text=nil;
    _password_lbl.text=nil;
    cell.notetxtview.hidden=true;
    
    
    NSString *documentsDirectory = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *filePath=[NSString stringWithFormat:@"%@/%@",documentsDirectory,@"userInfo.sqlite"];
    NSLog(@"%@",filePath);
    db = [FMDatabase databaseWithPath:filePath];
    
//    [db open];
//    
//    FMResultSet *resultsWithCollegeName = [db executeQuery:@"SELECT * FROM userData1 WHERE email=(?)", useridfield.text];
//    
//    while  ([resultsWithCollegeName next])
//    {
//        
//        enrolluser=[resultsWithCollegeName stringForColumn:@"enroll"];
//        genderuser=[resultsWithCollegeName stringForColumn:@"gender"];
//        nameuser=[resultsWithCollegeName stringForColumn:@"name"];
//        emailuser=[resultsWithCollegeName stringForColumn:@"email"];
//        contactuser=[resultsWithCollegeName stringForColumn:@"contact"];
//        datauser=[resultsWithCollegeName dataForColumn:@"image"];
//        passworduser=[resultsWithCollegeName stringForColumn:@"password"];
//        
//        NSLog(@"name %@", nameuser);
//
//    }
//    
//    [db close];
    
    
    UIAlertController * alertController = [UIAlertController alertControllerWithTitle: @"LOGIN.." message: @"Login first with valid cradential." preferredStyle:UIAlertControllerStyleAlert];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
       // NSString *usermatch=[NSString stringWithFormat:@"%@",[userarr [indexPath.row] valueForKey:@"email"]];
        
        textField.placeholder = @"UserID / Email";
        textField.textAlignment=NSTextAlignmentCenter;
        //textField.text=usermatch;
        textField.textColor = [UIColor blueColor];
       // textField.enabled=false;
         textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        textField.borderStyle = UITextBorderStyleRoundedRect;
        textField.layer.cornerRadius=5;
        textField.layer.masksToBounds=YES;
    }];
    
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"Password";
        textField.textAlignment=NSTextAlignmentCenter;
        textField.textColor = [UIColor blueColor];
        textField.secureTextEntry=YES;
        textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        textField.borderStyle = UITextBorderStyleRoundedRect;
        textField.layer.cornerRadius=5;
        textField.layer.masksToBounds=YES;
    }];
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"SignUp" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
        {
                [self dismissViewControllerAnimated:alertController completion:nil];
            [self.navigationController popToRootViewControllerAnimated:YES];
            
        }]];
    
    
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"SignIn" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
    {
        
        NSArray *textfields = alertController.textFields;
        UITextField *useridfield = textfields[0];
        UITextField *userpasswordfield = textfields [1];
        
        [db open];
        
        FMResultSet *resultsWithCollegeName = [db executeQuery:@"SELECT * FROM userData1 WHERE email=(?)", useridfield.text];
        
        while  ([resultsWithCollegeName next])
        {
            
            enrolluser=[resultsWithCollegeName stringForColumn:@"enroll"];
            genderuser=[resultsWithCollegeName stringForColumn:@"gender"];
            nameuser=[resultsWithCollegeName stringForColumn:@"name"];
            emailuser=[resultsWithCollegeName stringForColumn:@"email"];
            contactuser=[resultsWithCollegeName stringForColumn:@"contact"];
            datauser=[resultsWithCollegeName dataForColumn:@"image"];
            passworduser=[resultsWithCollegeName stringForColumn:@"password"];
            
            NSLog(@"name %@", nameuser);
            
            
            
            
        }
        
        [db close];
        
        
        if ( [userpasswordfield.text isEqualToString:passworduser])
        {
            [self.navigationController dismissViewControllerAnimated:alertController completion:nil];
            
            self.signout_btn.enabled=true;
            self.addnote_btn.enabled=true;
            self.deletuserinfo.enabled=true;
            self.usermenu_btn.enabled=true;
            
            [self.navigationItem setTitle:nameuser];
            
            _proimg_lbl.image=[UIImage imageWithData:datauser];
            _name_lbl.text=nameuser;
            _email_lbl.text=emailuser;
            _contact_lbl.text=contactuser;
            _gender_lbl.text=genderuser;
            _password_lbl.text=passworduser;
            cell.notetxtview.hidden=false;
           // cell.notetxtview.text=@"hy there, i m MS Dhoni indian cricketer, and a former indian captain.";
        }

        else
        {
            
            UIAlertController * alertController1 = [UIAlertController alertControllerWithTitle: @"Caution.." message: @"Login failed, please try again later." preferredStyle:UIAlertControllerStyleAlert];
            
            [alertController1 addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                {
                    [self dismissViewControllerAnimated:alertController1 completion:nil];
                    
                    [self presentViewController:alertController animated:YES completion:nil];
                    
                    
                }
                
            }]];
            
            
            
            [self presentViewController:alertController1 animated:YES completion:nil];
        }

        
    }]];
    
    
     [self presentViewController:alertController animated:YES completion:nil];
    
    // Do any additional setup after loading the view.
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    cell.notetxtview.text=@"hy there, i m MS Dhoni indian cricketer, and a former indian captain.";
    return cell;
    
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)signout:(id)sender {
    
    [self.navigationController popToRootViewControllerAnimated:YES];
    
}




@end
