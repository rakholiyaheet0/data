//
//  noteTableViewCell.m
//  FMDB_Validation_login
//
//  Created by kavi on 16/02/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import "noteTableViewCell.h"

@implementation noteTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
