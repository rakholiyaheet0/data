//
//  ViewController.h
//  FMDB_Validation_login
//
//  Created by kavi on 14/02/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FMResultSet.h"
#import "FMDB.h"
#import "FMDatabase.h"
#import <sqlite3.h>

@interface ViewController : UIViewController<UIImagePickerControllerDelegate,UITextFieldDelegate>
{
    FMDatabase *db;
    
}


@property (strong,nonatomic) IBOutlet UIBarButtonItem *img_btn;
- (IBAction)proimage:(id)sender;
@property (strong,nonatomic) IBOutlet UIBarButtonItem *resister_btn;
- (IBAction)resteruser:(id)sender;
@property (strong,nonatomic) IBOutlet UIBarButtonItem *userinfo;
- (IBAction)userinfo:(id)sender;
@property (strong,nonatomic) IBOutlet UIBarButtonItem *log_btn;
- (IBAction)loginuser:(id)sender;

@property (strong,nonatomic) IBOutlet UIImageView *profile_img;

@property (strong,nonatomic) IBOutlet UISegmentedControl *gender_segmt;


@property (strong,nonatomic) IBOutlet UITextField *enroll_txt;

@property (strong,nonatomic) IBOutlet UITextField *fname_txt;

@property (strong,nonatomic) IBOutlet UITextField *email_txt;

@property (strong,nonatomic) IBOutlet UITextField *contact_txt;

@property (strong,nonatomic) IBOutlet UITextField *password_txt;

@property (strong,nonatomic) IBOutlet UITextField *confirmpass_txt;








@end

