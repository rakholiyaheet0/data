//
//  userTableViewCell.h
//  FMDB_Validation_login
//
//  Created by kavi on 15/02/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface userTableViewCell : UITableViewCell



@property (strong,nonatomic) IBOutlet UILabel *enroll_lbl;
@property (strong,nonatomic) IBOutlet UILabel *name_lbl;
@property (strong,nonatomic) IBOutlet UILabel *contact_lbl;
@property (strong,nonatomic) IBOutlet UILabel *gender_lbl;
@property (strong,nonatomic) IBOutlet UILabel *email_lbl;

@property (strong,nonatomic) IBOutlet UIImageView *proimg_lbl;





@end
