//
//  ViewController.m
//  FMDB_Validation_login
//
//  Created by kavi on 14/02/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import "ViewController.h"
#import "FMDB.h"
#import "FMDatabase.h"
#import "FMResultSet.h"
#import <sqlite3.h>
#import "userinfoViewController.h"
#import "userloginViewController.h"

@interface ViewController ()
{
    NSString *gender_str;
    NSMutableArray *textarr;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
        NSLog(@"disable");
      //  self.resister_btn.enabled=false;

   
    [self.navigationItem setTitle:@"SIGN_UP"];
    
    _profile_img.layer.cornerRadius=75;
    _profile_img.layer.borderWidth=0.5;
    _profile_img.layer.masksToBounds=YES;
    
    _enroll_txt.delegate=self;
    _fname_txt.delegate=self;
    _email_txt.delegate=self;
    _contact_txt.delegate=self;
    _password_txt.delegate=self;
    _confirmpass_txt.delegate=self;
    


    
    
    
    textarr =[[NSMutableArray alloc]init];
    if (textarr.count<=4)
    {
        self.resister_btn.enabled=false;
    }
    
    
}
- (IBAction)indexchange:(UISegmentedControl *)sender {
    
    switch (self.gender_segmt.selectedSegmentIndex)
    {
        case 0:
            gender_str = @"Male";
            break;
        case 1:
            gender_str = @"Female";
            break;
        default: 
            break; 
    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)proimage:(id)sender {
    
    UIImagePickerController *picker = [[UIImagePickerController alloc]init];
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.allowsEditing = YES;
    picker.delegate = self;
    
    
    [self presentViewController:picker animated:YES completion:nil];

}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *chosenImg = info[UIImagePickerControllerEditedImage];
    self.profile_img.image = chosenImg;
    
    [picker dismissViewControllerAnimated:YES completion:nil];
    
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField;
{
    
    if ( textField==_enroll_txt) {
        
        NSString *intstr=[NSString stringWithFormat:@"%d",_enroll_txt.text.intValue];
        
        if (_enroll_txt.text != intstr)
        {
            UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"Alert" message:@"Entre intiger value only." preferredStyle:UIAlertControllerStyleAlert];

            UIAlertAction *Ok_btn  = [UIAlertAction
                                        actionWithTitle:@"OK"
                                        style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action) {
                                            
                                            
                                            //Handle your yes please button action here
                         }];
            _enroll_txt.text=@"";
            [alert addAction:Ok_btn];
            [self presentViewController:alert animated:YES completion:nil];
            
        }
        
       else if(_enroll_txt.text.length < 2)
        {
            
            UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"Alert" message:@"Entre intiger value only in double figure." preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction *Ok_btn  = [UIAlertAction
                                      actionWithTitle:@"OK"
                                      style:UIAlertActionStyleDefault
                                      handler:^(UIAlertAction * action) {
                                          
                                    //Handle your yes please button action here
                                      }];
            _enroll_txt.text=@"";
            [alert addAction:Ok_btn];
            [self presentViewController:alert animated:YES completion:nil];
        }
        else
        {
            [textarr addObject:_enroll_txt.text];
            NSLog(@"%@",gender_str);
        }
    }
    
    else if (textField == _fname_txt)
    {
        if (_fname_txt.text.length <= 4)
        {
            UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"Alert" message:@"Entre full Name. minimum 5 charactre." preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction *Ok_btn  = [UIAlertAction
                                      actionWithTitle:@"OK"
                                      style:UIAlertActionStyleDefault
                                      handler:^(UIAlertAction * action) {
                                          
                                          //Handle your yes please button action here
                                      }];
            _fname_txt.text=@"";
            [alert addAction:Ok_btn];
            [self presentViewController:alert animated:YES completion:nil];
        

        }
        else
        {
            [textarr addObject:_fname_txt.text];
        }
        
    }
    
    else if (textField == _email_txt)
    {
      //  NSString *checkString;
         BOOL stricterFilter = NO;
        NSString *stricterFilterString = @"^[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$";
        NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
        NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
        //NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
        NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
       // [emailTest evaluateWithObject:checkString];
        
        
        if ([emailTest evaluateWithObject:_email_txt.text])
        {
            [textarr addObject:_email_txt.text];
            NSLog(@"no problem found.");
        }
        else
        {
            UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"Alert" message:@"Entre Valid Email Address and try again later." preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction *Ok_btn  = [UIAlertAction
                                      actionWithTitle:@"OK"
                                      style:UIAlertActionStyleDefault
                                      handler:^(UIAlertAction * action) {
                                          
                                          //Handle your yes please button action here
                                      }];
            _email_txt.text=@"";
            [alert addAction:Ok_btn];
            [self presentViewController:alert animated:YES completion:nil];
        }
    }
    
    else if (textField == _contact_txt)
    {
        if (_contact_txt.text.length == 10) {
            NSLog(@"%@",_contact_txt.text);
            [textarr addObject:_contact_txt.text];
        }
        
        else if (_contact_txt.text.length <=9)
        {
            UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"Alert" message:@"Entre valid contact number." preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction *Ok_btn  = [UIAlertAction
                                      actionWithTitle:@"OK"
                                      style:UIAlertActionStyleDefault
                                      handler:^(UIAlertAction * action) {
                                          
                                          //Handle your yes please button action here
                                      }];
            _contact_txt.text=@"";
            [alert addAction:Ok_btn];
            [self presentViewController:alert animated:YES completion:nil];

        }
    }
    else if (textField == _password_txt)
    {
        //self.resister_btn.enabled=true;
        
        NSString *stricterFilterString = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[$@$#!%*?&])[A-Za-z\\d$@$#!%*?&]{8,}";
        NSPredicate *passwordTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", stricterFilterString];
       // return [passwordTest evaluateWithObject:checkString];
        
        if([textField.text length] >= 8)
        {
          if ([passwordTest evaluateWithObject:_password_txt.text])
          {
              NSLog(@"pass %@",_password_txt.text);
              [textarr addObject:_password_txt.text];
              NSLog(@"%@",gender_str);
             
              if (textarr.count==5) {
                  self.resister_btn.enabled=true;
              }
              
          }
            else
            {
                UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"Alert" message:@"Please Ensure that you have at least one lower case letter, one upper case letter, one digit and one special character." preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction *Ok_btn  = [UIAlertAction
                                          actionWithTitle:@"OK"
                                          style:UIAlertActionStyleDefault
                                          handler:^(UIAlertAction * action) {
                                              
                                              //Handle your yes please button action here
                                          }];
                _password_txt.text=@"";
                [alert addAction:Ok_btn];
                [self presentViewController:alert animated:YES completion:nil];
 
            }
        
        }
            
        
        else
        {
            UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"Alert" message:@"Entre password atleast using 8 charactre." preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction *Ok_btn  = [UIAlertAction
                                      actionWithTitle:@"OK"
                                      style:UIAlertActionStyleDefault
                                      handler:^(UIAlertAction * action) {
                                          
                                          //Handle your yes please button action here
                                      }];
            _password_txt.text=@"";
            [alert addAction:Ok_btn];
            [self presentViewController:alert animated:YES completion:nil];
        }
    }
    
    else if (textField ==_confirmpass_txt)
    {
        NSString *confirm=[NSString stringWithFormat:@"%@", _confirmpass_txt.text];
        
        if ([_confirmpass_txt.text isEqualToString:confirm])
        {
            NSLog(@"%@",_confirmpass_txt.text);
            
            NSLog(@"%@",textarr);
            
        }
        
        else
        {
            UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"Alert" message:@"Please entre correct password to confirm." preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction *Ok_btn  = [UIAlertAction
                                      actionWithTitle:@"OK"
                                      style:UIAlertActionStyleDefault
                                      handler:^(UIAlertAction * action) {
                                          
                                          //Handle your yes please button action here
                                      }];
            _confirmpass_txt.text=@"";
            [alert addAction:Ok_btn];
            [self presentViewController:alert animated:YES completion:nil];
        }
    }
    
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField == _enroll_txt)
    {
    
    if (textField.text.length >= 2 && range.length == 0)
        return NO;
    }
    else if (textField == _fname_txt)
    {
        if (textField.text.length >= 15 && range.length == 0)
            return NO;
     }
    else if (textField == _contact_txt)
    {
        if (textField.text.length >= 10 && range.length == 0)
            return NO;
    }
    
    return YES;
}




- (IBAction)resteruser:(id)sender {
    
    UIImage *image=self.profile_img.image;
    
    
    NSData* data = UIImagePNGRepresentation(image);
    
    
    NSString *documentsDirectory = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *filePath=[NSString stringWithFormat:@"%@/%@",documentsDirectory,@"userInfo.sqlite"];
    NSLog(@"%@",filePath);
    db = [FMDatabase databaseWithPath:filePath];
    if (![db open])
    {
        return;
    }
    
    [db executeUpdate: @"INSERT INTO userData1 VALUES (? ,? ,? ,?, ?, ?, ? )" ,_enroll_txt.text, gender_str,_fname_txt.text,_email_txt.text,_contact_txt.text,_password_txt.text, data];
    
    
    [db close];
    
    
    _enroll_txt.text = @"";
    _fname_txt.text = @"";
    _email_txt.text = @"";
    _contact_txt.text=@"";
    _password_txt.text=@"";
    _confirmpass_txt.text=@"";
    
    [textarr removeAllObjects];
    if (textarr.count<=3)
    {
        self.resister_btn.enabled=false;
    }
    
}











- (IBAction)userinfo:(id)sender {
    
    
    userinfoViewController *userdetail=[self.storyboard instantiateViewControllerWithIdentifier:@"userinfoViewController"];
    [self.navigationController pushViewController:userdetail animated:YES];
}













- (IBAction)loginuser:(id)sender {
    
    userloginViewController *userlogin=[self.storyboard instantiateViewControllerWithIdentifier:@"userloginViewController"];
    [self.navigationController pushViewController:userlogin animated:YES];
}

















@end
