//
//  main.m
//  FMDB_Validation_login
//
//  Created by kavi on 14/02/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
