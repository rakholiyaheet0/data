//
//  AppDelegate.h
//  LGMenuDemo
//
//  Created by Apple on 25/01/17.
//  Copyright © 2017 Jignesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

