//
//  MenuViewController.m
//  LGMenuDemo
//
//  Created by Apple on 25/01/17.
//  Copyright © 2017 Jignesh. All rights reserved.
//

#import "LeftViewController.h"
#import "UIViewController+LGSideMenuController.h"
#import "leftTableViewCell.h"
#import "AppDelegate.h"
#define APPDELEGATE ((AppDelegate*)[[UIApplication sharedApplication] delegate])


@interface LeftViewController ()
{
    NSMutableArray *arr;
    NSArray *SectionTitleArray;
    NSMutableArray *arrstatus;
    NSMutableArray *sectionarr;
    NSMutableArray *imgarr;
    NSMutableArray *accountsubmenuarr;
    NSInteger index;
    UIButton *viewall_btn;
    NSMutableArray *arr2;
    UIButton *btnimage;
    leftTableViewCell *cell;

    
}
@end

@implementation LeftViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
     tab.backgroundColor = [UIColor grayColor];
    //arrstatus=[nsmu];
    imgarr=[[NSMutableArray alloc]initWithObjects:@"event information.png",@"register.png",@"upgrade.png",@"my event.jpeg",@"exhibitor.jpeg",@"sessions.png",@"speakers.png",@"floorplan.jpeg",@"social media.png",@"scan.jpeg",@"around town.jpeg",@"login.jpeg",@"about app.jpeg",nil];
    NSLog(@"%@",imgarr);
    
    SectionTitleArray=@[@"Event Information",@"Register",@"Upgrade",@"My Event",@"Exhibitors",@"Sessions",@"Speakers",@"Floor Plan",@"Social Media",@"Scan",@"Around Town",@"Login",@"About App"];
    //.......
    /*
    UIView *parent=self.view;
    NSLayoutConstraint *width =[NSLayoutConstraint
                                constraintWithItem:btnimage
                                attribute:NSLayoutAttributeWidth
                                relatedBy:NSLayoutRelationEqual
                                toItem:btnimage
                                attribute:NSLayoutAttributeTrailing
                                multiplier:1.0f
                                constant:35];
    
    
    
    NSLayoutConstraint *height = [NSLayoutConstraint
                                  constraintWithItem:btnimage
                                  attribute:NSLayoutAttributeHeight
                                  relatedBy:NSLayoutRelationEqual
                                  toItem:btnimage
                                  attribute:NSLayoutAttributeNotAnAttribute
                                  multiplier:0
                                  constant:35];
    [btnimage.superview addConstraint:[NSLayoutConstraint
                                       constraintWithItem:btnimage.superview
                                       attribute:NSLayoutAttributeLeft
                                       relatedBy:NSLayoutRelationEqual
                                       toItem:btnimage
                                       attribute:NSLayoutAttributeLeft
                                       multiplier:1.0
                                       constant:0]];
    
    
    NSLayoutConstraint *leading = [NSLayoutConstraint
                                   constraintWithItem:btnimage
                                   attribute:NSLayoutAttributeLeading
                                   relatedBy:NSLayoutRelationEqual
                                   toItem:self.view
                                   attribute:NSLayoutAttributeLeading
                                   multiplier:1
                                   constant:8];
                        [btnimage addConstraint:
                         [NSLayoutConstraint constraintWithItem:btnimage
                                  attribute:NSLayoutAttributeCenterY
                                  relatedBy:0
                                     toItem:self.view
                                  attribute:NSLayoutAttributeCenterY
                                 multiplier:1
                                   constant:0]];
    
    

    [parent addConstraint:leading];
    
    [self.view addConstraint:height];
    [self.view addConstraint:width];
    */
    //........
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0)
    {
        return arr.count;
        
    }
    else if (section == 8)
    {
        return arr2.count;
    }
    else
    {
        return 0;
    }

    
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return SectionTitleArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 90;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 1;
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
    UIView *table_headerview=[[UIView alloc]initWithFrame:CGRectMake(0,0,[UIScreen mainScreen].bounds.size.width,90)];
 
    table_headerview.backgroundColor=[UIColor blackColor];//
    
    UIImageView *squ_view=[[UIImageView alloc]initWithFrame:CGRectMake(15,20,50,50)];
    
    squ_view.backgroundColor=[UIColor lightGrayColor];
    
    squ_view.image=[UIImage imageNamed:[imgarr objectAtIndex:section]];
    //squ_view.image=[UIImage imageNamed:@"3.jpeg"];
    
    
    
    [table_headerview addSubview:squ_view];
    
    UILabel *section_title=[[UILabel alloc]initWithFrame:CGRectMake(squ_view.frame.origin.x + squ_view.frame.size.width + 20 ,33,200,21)];
    section_title.font = [UIFont boldSystemFontOfSize:18];
    section_title.font=[UIFont systemFontOfSize:18 weight:UIFontWeightBold];
    
    
    section_title.textColor=[UIColor whiteColor];
    
    section_title.text=[SectionTitleArray objectAtIndex:section];
   
    
    
    
    viewall_btn=[[UIButton alloc]initWithFrame:CGRectMake(table_headerview.frame.origin.x,table_headerview.frame.origin.y,table_headerview.frame.size.width,table_headerview.frame.size.height)];
    
    viewall_btn.tintColor=[UIColor redColor];
    
    viewall_btn.tag=section;
    
    [viewall_btn addTarget:self action:@selector(viewallclick:) forControlEvents:UIControlEventTouchUpInside];
    
    viewall_btn.backgroundColor=[UIColor clearColor];
    
    [table_headerview addSubview:viewall_btn];
    
    [table_headerview addSubview:section_title];
    //........................
    
    btnimage=[UIButton buttonWithType:UIButtonTypeCustom];
    btnimage.frame=CGRectMake(350, 25, 35, 35);
    UIImage *colorimage = [UIImage imageNamed:@"downarraw.png"];
    [btnimage setBackgroundImage:colorimage forState:UIControlStateNormal];
   // [table_headerview addSubview:btnimage];
    
    // ................
    if (section==0 ||section==8) {
        [table_headerview addSubview:btnimage];
        btnimage.hidden=NO;
    }
    else
    {
        btnimage.hidden=YES;
    }
    
    
    
    
    //.................
    //........................
    
    return table_headerview;
}

-(IBAction)viewallclick:(UIButton*)sender
{
    if (sender.tag==0)
    {
        if (arr.count==0)
        {
            arr=[[NSMutableArray alloc]initWithObjects:@"General Information",@"Show Schedule",@"Transportation",@"Housing",@"Dining", nil];
        }
        else
        {
            [arr removeAllObjects];
        }
        
        NSIndexSet *SET=[NSIndexSet indexSetWithIndex:0];
        
        [tab reloadSections:SET withRowAnimation:UITableViewRowAnimationFade];
        
    }
    else if (sender.tag==8)
    {
        if (arr2.count==0)
        {
            arr2=[[NSMutableArray alloc]initWithObjects:@"Facebook",@"Twitter",@"Linkedin", nil];
        }
        else
        {
            [arr2 removeAllObjects];
        }
        
        NSIndexSet *SET=[NSIndexSet indexSetWithIndex:8];
        
        [tab reloadSections:SET withRowAnimation:UITableViewRowAnimationFade];
        
    }

    
    
}


-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    cell=[tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    cell.btnArrowup_down.hidden=false;
    cell.backgroundColor = [UIColor grayColor];
    cell.lblcelldata.textColor = [UIColor whiteColor];
   
   
    if (indexPath.section==0)
    {
        cell.lblcelldata.text=[arr objectAtIndex:indexPath.row];
        cell.btnArrowup_down.hidden=true;
    }
  else  if (indexPath.section==8)
    {
        cell.lblcelldata.text=[arr2 objectAtIndex:indexPath.row];
        cell.btnArrowup_down.hidden=true;
    }
    else
    {
        cell.btnArrowup_down.hidden=false;

        
    }
    
    

    return cell;

}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    return 70;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    
}
- (IBAction)btncancelclicked:(id)sender {
    [self hideLeftViewAnimated:NULL];
    
}


@end
