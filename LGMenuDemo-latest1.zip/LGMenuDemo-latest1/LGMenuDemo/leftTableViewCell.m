//
//  leftTableViewCell.m
//  LGMenuDemo
//
//  Created by pixometry on 25/01/17.
//  Copyright © 2017 Jignesh. All rights reserved.
//

#import "leftTableViewCell.h"

@implementation leftTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
