//
//  ViewController.m
//  LGMenuDemo
//
//  Created by Apple on 25/01/17.
//  Copyright © 2017 Jignesh. All rights reserved.
//

#import "MainViewController.h"
#import "LeftViewController.h"

@interface MainViewController ()

@property (assign, nonatomic) NSUInteger type;

@end

@implementation MainViewController

- (void)viewDidLoad{
    [super viewDidLoad];
    self.leftViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"LeftViewController"];
    self.rootViewController  = [self.storyboard instantiateViewControllerWithIdentifier:@"HomeNavigationViewController"];
     self.leftViewWidth = [UIScreen mainScreen].bounds.size.width;
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    
}

@end
