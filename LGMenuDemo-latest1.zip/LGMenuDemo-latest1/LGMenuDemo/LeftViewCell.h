//
//  LeftViewCell.h
//  LGMenuDemo
//
//  Created by pixometry on 25/01/17.
//  Copyright © 2017 Jignesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftViewCell : UITableViewCell
{
    
}
@property(strong,nonatomic)IBOutlet UIImageView *cellimage;
@property(strong,nonatomic)IBOutlet UILabel *lblcell;
@property(strong,nonatomic)IBOutlet UIImageView *arrowimage;
@end
