//
//  leftTableViewCell.h
//  LGMenuDemo
//
//  Created by pixometry on 25/01/17.
//  Copyright © 2017 Jignesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface leftTableViewCell : UITableViewCell
{
    
}
@property(strong,nonatomic)IBOutlet UIImageView *cellimage;
@property(strong,nonatomic)IBOutlet UILabel *lblcelldata;
@property(strong,nonatomic)IBOutlet UIButton *btnArrowup_down;

@end
