//
//  HomeViewController.h
//  LGMenuDemo
//
//  Created by pixometry on 25/01/17.
//  Copyright © 2017 Jignesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewController : UIViewController

@end
