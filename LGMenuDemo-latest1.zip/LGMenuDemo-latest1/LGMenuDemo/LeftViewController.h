//
//  MenuViewController.h
//  LGMenuDemo
//
//  Created by Apple on 25/01/17.
//  Copyright © 2017 Jignesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
       IBOutlet UITableView *tab;
    IBOutlet UIButton *btncancelmenu;
    
}
@end
