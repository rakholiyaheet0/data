//
//  HomeViewController.m
//  LGMenuDemo
//
//  Created by pixometry on 25/01/17.
//  Copyright © 2017 Jignesh. All rights reserved.
//

#import "HomeViewController.h"
#import "UIViewController+LGSideMenuController.h"

@interface HomeViewController ()

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}
- (IBAction)onBtnMenuClicked:(id)sender {
    [self toggleLeftViewAnimated:NULL];
}
@end
