//
//  ViewController.h
//  materialdesign_textfiled_placeholder_demo
//
//  Created by Hemant Gupta on 6/10/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JJMaterialTextField.h"

@interface ViewController : UIViewController
{
    
}
@property(strong,nonatomic)IBOutlet JJMaterialTextfield *txt_email;

@end

