//
//  ViewController.m
//  materialdesign_textfiled_placeholder_demo
//
//  Created by Hemant Gupta on 6/10/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import "ViewController.h"
#import "JJMaterialTextField.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize txt_email;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    txt_email.textColor=[UIColor blackColor];
   
    txt_email.enableMaterialPlaceHolder=YES;
    txt_email.errorColor=[UIColor colorWithRed:0.910 green:0.329 blue:0.271 alpha:1.000]; // FLAT RED COLOR
    txt_email.lineColor=[UIColor colorWithRed:0.482 green:0.800 blue:1.000 alpha:1.000];
    txt_email.tintColor=[UIColor colorWithRed:0.482 green:0.800 blue:1.000 alpha:1.000];
    //txt_email.lineColor=[UIColor colorWithRed:0.482 green:0.800 blue:1.000 alpha:1.000];
    txt_email.placeholder=@"Username";
    [self.view addSubview:txt_email];
    txt_email.placeholderAttributes = @{NSFontAttributeName : [UIFont systemFontOfSize:20],
                                        NSForegroundColorAttributeName : [[UIColor grayColor] colorWithAlphaComponent:.8]};
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
