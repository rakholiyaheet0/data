//
//  ViewController.h
//  DEMO_AFNEWTWORKING
//
//  Created by Hemant Gupta on 6/11/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFNetworking.h"
#import "AFHTTPSessionManager.h"
@interface ViewController : UIViewController
{
    
}
@property(strong,nonatomic)IBOutlet UIButton *btn_fetchData;
@property(strong,nonatomic)IBOutlet UILabel *lbl1;
@property(strong,nonatomic)IBOutlet UILabel *lbl2;

@end

