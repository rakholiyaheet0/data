//
//  ViewController.m
//  DEMO_AFNEWTWORKING
//
//  Created by Hemant Gupta on 6/11/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import "ViewController.h"
#import "MBProgressHUD.h"
//#import <MBProgressHUD/MBProgressHUD.h>

@interface ViewController ()
{
    NSArray *arrList;
}
@end
//static MBProgressHUD *loadinView;
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //[self showLoading:loadinView];
//    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
//    hud.labelText=@"Loading";
//    
//    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
//    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
//    [manager GET:@"http://api.geonames.org/countryInfoJSON?username=kuldip" parameters:nil progress:nil success:^(NSURLSessionTask *task, id responseObject) {
//        NSError *error = nil;
//        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
//        NSLog(@"JSON: %@", json);
//        arrList = [[NSArray alloc] initWithArray:[json valueForKey:@"geonames"]];
//        [MBProgressHUD hideHUDForView:self.view animated:YES];
//        //[self.tblView reloadData];
//    } failure:^(NSURLSessionTask *operation, NSError *error) {
//        NSLog(@"Error: %@", error);
//    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//- (void)showLoading : (UIView *)view
//{
//    loadinView = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
//    loadinView.mode = MBProgressHUDModeIndeterminate;
//    loadinView.labelText = @"Loading";
//}
-(IBAction)btn_fetchData:(id)sender
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText=@"Loading";
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager GET:@"http://api.geonames.org/countryInfoJSON?username=kuldip" parameters:nil progress:nil success:^(NSURLSessionTask *task, id responseObject) {
        NSError *error = nil;
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
        NSLog(@"JSON: %@", json);
         [MBProgressHUD hideHUDForView:self.view animated:YES];
        arrList = [[NSArray alloc] initWithArray:[json valueForKey:@"geonames"]];
        _lbl1.text=[[arrList objectAtIndex:1]valueForKey:@"capital"];
        _lbl2.text=[[arrList objectAtIndex:2]valueForKey:@"continent"];
       
        //[self.tblView reloadData];
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        NSLog(@"Error: %@", error);
    }];

}

@end
