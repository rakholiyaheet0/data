//
//  AppDelegate.h
//  DEMO_AFNEWTWORKING
//
//  Created by Hemant Gupta on 6/11/17.
//  Copyright © 2017 Hemant Gupta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

