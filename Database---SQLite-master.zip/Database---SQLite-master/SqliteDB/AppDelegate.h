//
//  AppDelegate.h
//  SqliteDB
//
//  Created by Pavankumar Arepu on 24/02/2016.
//  Copyright © 2016 ppam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Model.h"


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

