//
//  SViewController.h
//  Age_Cal
//
//  Created by hitesh rakholiya on 03/08/16.
//  Copyright (c) 2016 hitesh rakholiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SViewController : UIViewController
{
    IBOutlet UIImageView *img2;
    IBOutlet UILabel *lb1;
    IBOutlet UILabel *lb2;
    IBOutlet UILabel *lb3;
    IBOutlet UILabel *lb4;
    IBOutlet UIButton *btn;
    //IBOutlet UIButton *b;
}
@property (nonatomic,strong) NSString *st, *st1, *st2, *st3, *st4;
@end
