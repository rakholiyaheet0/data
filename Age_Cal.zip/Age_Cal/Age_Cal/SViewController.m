//
//  SViewController.m
//  Age_Cal
//
//  Created by hitesh rakholiya on 03/08/16.
//  Copyright (c) 2016 hitesh rakholiya. All rights reserved.
//

#import "SViewController.h"
#import "ViewController.h"

@interface SViewController ()
{
    int a,b;
    float c;
}

@end

@implementation SViewController
@synthesize st, st1, st2, st3, st4;

- (void)viewDidLoad {
    [super viewDidLoad];
    a=10;
    b=20;
    c=a+b;
    NSLog(@"%f",c);
    
    lb1.text=st;
    lb2.text=st1;
    lb3.text=st2;
    lb4.text=st3;
    btn.backgroundColor=nil;
    btn.titleLabel.text=nil;
    
    
   
    
    // b1=[[UIButton alloc]initWithFrame:CGRectMake(150, 150, 50, 10)];
    //b1.backgroundColor=[UIColor lightGrayColor];
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*-(void) aMethod: (id) sender{
    UIButton *b1= (UIButton*)sender;
    if (b1.tag == 1) {
    
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"hi" message:nil delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
    [alert show];
    }*/
    

    
- (IBAction)btn:(id)sender {
    if ([st4 isEqualToString:@"kavi"]) {
        
    
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Apple" message:nil delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
    [alert show];
    }
    else  if ([st4 isEqualToString:@"k"]) {
        
        
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"CocaCola" message:nil delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
        [alert show];
    }
    else  if ([st4 isEqualToString:@"ka"]) {
        
        
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Harley-Davidson" message:nil delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
        [alert show];
    }
    else  if ([st4 isEqualToString:@"kav"]) {
        
        
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Ferrari" message:nil delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
        [alert show];
    }


}


@end
