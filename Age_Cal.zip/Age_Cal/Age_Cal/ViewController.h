//
//  ViewController.h
//  Age_Cal
//
//  Created by hitesh rakholiya on 03/08/16.
//  Copyright (c) 2016 hitesh rakholiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    IBOutlet UIImageView *img;
    IBOutlet UITableView *tb;
    UIImageView *img2;
    NSMutableArray *arr, *arr2;
    NSString *str, *str1, *str2, *str3, *str4;
}

@end

