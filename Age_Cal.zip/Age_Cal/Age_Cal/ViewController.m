//
//  ViewController.m
//  Age_Cal
//
//  Created by hitesh rakholiya on 03/08/16.
//  Copyright (c) 2016 hitesh rakholiya. All rights reserved.
//

#import "ViewController.h"
#import "SViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    arr=[[NSMutableArray alloc]initWithObjects:@"Fruits",@"Drinks",@"Bikes",@"Cars", nil];
    arr2=[[NSMutableArray alloc]initWithObjects:[UIImage imageNamed:@"1.jpg"],[UIImage imageNamed:@"2.png"],[UIImage imageNamed:@"1.jpg"],[UIImage imageNamed:@"2.png"], nil];
    tb.backgroundColor=nil;//[UIColor grayColor];
    

    // Do any additional setup after loading the view, typically from a nib.

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView;
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    return 100;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    return arr.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    cell.textLabel.text=[arr objectAtIndex:indexPath.row];
    
    cell.textLabel.textAlignment=NSTextAlignmentCenter;
    cell.backgroundColor=nil;//[UIColor lightGrayColor];
    //cell.imageView.image=[UIImage imageNamed:@"2.jpg"];
    img2=[[UIImageView alloc]initWithFrame:CGRectMake(10, 10, 80, 80)];
    img2.layer.cornerRadius=40;
    img2.layer.masksToBounds=YES;
    img2.image=[arr2 objectAtIndex:indexPath.row];
    //cell.textLabel.text=lb.text;
    [cell addSubview:img2];

    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    SViewController *sec=[[SViewController alloc]initWithNibName:@"SViewController" bundle:nil];
    if (indexPath.row==0) {
        str=@"Apple";
        str1=@"Banana";
        str2=@"Graps";
        str3=@"Cheri";
        str4=@"kavi";
        sec.st=str;
        sec.st1=str1;
        sec.st2=str2;
        sec.st3=str3;
        sec.st4=str4;
        [self.navigationController pushViewController:sec animated:YES];
    }
    else if (indexPath.row==1)
    {
        str=@"CocaCola";
        str1=@"Pepsi";
        str2=@"Phizz";
        str3=@"RedBull";
        str4=@"k";
        sec.st=str;
        sec.st1=str1;
        sec.st2=str2;
        sec.st3=str3;
        sec.st4=str4;
        [self.navigationController pushViewController:sec animated:YES];
    }
    else if (indexPath.row==2)
    {
        str=@"Harley-Davidson";
        str1=@"Royan Enfield";
        str2=@"Avengers";
        str3=@"Hunk";
        str4=@"ka";
        sec.st=str;
        sec.st1=str1;
        sec.st2=str2;
        sec.st3=str3;
        sec.st4=str4;
        [self.navigationController pushViewController:sec animated:YES];
    }
    else if (indexPath.row==3)
    {
        str=@"Ferrari";
        str1=@"BMW";
        str2=@"Audi";
        str3=@"Jeguar";
        str4=@"kav";
        sec.st=str;
        sec.st1=str1;
        sec.st2=str2;
        sec.st3=str3;
        sec.st4=str4;
        [self.navigationController pushViewController:sec animated:YES];
    }
    else
        
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"Access Denied" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
}
@end
