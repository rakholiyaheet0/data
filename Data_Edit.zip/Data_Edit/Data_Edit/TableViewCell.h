//
//  TableViewCell.h
//  Data_Edit
//
//  Created by kavi on 07/01/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "ViewController.h"

@interface TableViewCell : UITableViewCell


@property(strong,nonatomic) IBOutlet UILabel *lbl;
@property(strong,nonatomic) IBOutlet UILabel *lbl1;
@property(strong,nonatomic) IBOutlet UILabel *lbl2;


@end
