//
//  ViewController.m
//  Data_Edit
//
//  Created by kavi on 07/01/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import "ViewController.h"
#import "SViewController.h"

@interface ViewController () <SViewControllerDelegate>

@end

@implementation ViewController

{
    //TableViewCell *cell;
    bool kavi;
}
@synthesize datatns,middle,selectcell,arr4,deselectcell,arr;




- (void)viewDidLoad
{
    [super viewDidLoad];
    
    arr4=nil;

    
    
    
    
    arr4=[[NSMutableArray alloc]init];

    
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    
    
  //  [[self navigationController] setNavigationBarHidden:NO animated:YES];
    
    self.selectcell=[NSMutableArray array];
    self.deselectcell=[NSMutableArray array];
    self.arr4=[NSMutableArray array];
    
    // [tab registerNib:[UINib nibWithNibName:@"TableViewCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"cell"];
    
    self.arr =[[NSMutableArray alloc]initWithObjects: @"Kavi",@"Heet",@"Vin",@"Malik",@"Uday", nil];
     arr1=[[NSMutableArray alloc]initWithObjects:@"iOS DEveloper",@"iOS Developer",@"Accounting",@"BE Degree",@"Student", nil];
     arr2=[[NSMutableArray alloc]initWithObjects:@"Vaghaniya",@"Vaghaniya",@"Vaghaniya",@"Medi",@"Bhayavadar", nil];
    
    middle=[[NSString alloc]init];
    
    //NSLog(@"%@",middle);
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arr.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    //cell=[tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    
    cell.textLabel.text=[arr objectAtIndex:indexPath.row];
    cell.textLabel.textAlignment=NSTextAlignmentCenter;
    
    //[arr replaceObjectAtIndex:indexPath.row withObject:datatns];
    
  // cell.lbl.text=[arr objectAtIndex:indexPath.row];
//    cell.lbl1.text=[arr1 objectAtIndex:indexPath.row];
//
//    cell.lbl2.text=[arr2 objectAtIndex:indexPath.row];

   // NSLog(@"%@",datatns);
    
    return cell;
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    //[tab resignFirstResponder];
   // [tab remembersLastFocusedIndexPath];
    
    NSString *state = [self.arr objectAtIndex:indexPath.row];
    
//        cell = [tableView cellForRowAtIndexPath:indexPath];
//    
//    [tableView deselectRowAtIndexPath:[tableView indexPathForSelectedRow] animated:NO];
//    
//    cell.img.image=[UIImage imageNamed:@"1.png"];
//    
//    if ((cell.img.image=[UIImage imageNamed:@"1.png"])) {
//        
//        
//       // cell.accessoryType = UITableViewCellAccessoryNone;
//        cell.img.image=[UIImage imageNamed:@"2.png"];
//        // Reflect selection in data model
//        
//        
//    }
//    
//     else if ((cell.img.image=[UIImage imageNamed:@"2.png"])) {
//        
//         cell.img.image=[UIImage imageNamed:@"1.png"];
//
//        
//       // cell.accessoryType = UITableViewCellAccessoryCheckmark;
//        // Reflect deselection in data model
//    }
//
       // [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath, nil] withRowAnimation:UITableViewRowAnimationAutomatic];
    [tableView deselectRowAtIndexPath:[tableView indexPathForSelectedRow] animated:NO];
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    

    
    if (cell.accessoryType == UITableViewCellAccessoryNone) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
        kavi=true;
        [self.arr4 addObject:state];
        
        // Reflect selection in data model
    } else if (cell.accessoryType == UITableViewCellAccessoryCheckmark) {
        cell.accessoryType = UITableViewCellAccessoryNone;
        kavi=false;
         [self.arr4 removeObject:state];
        // Reflect deselection in data model
    }


   // return self;
    
   // NSLog(@"%@",deselectcell);
    
   }


//-(BOOL)isRowSelectedOnTableView:(UITableView *)tableView atIndexPath:(NSIndexPath *)indexPath
//{
//    return ([self.selectcell containsObject:indexPath]) ? YES : NO;
//}

- (void)dataFromController:(NSString *)data
{
    datatns=data;
    NSLog(@"Data Back %@",datatns);
    [arr replaceObjectAtIndex:tab.indexPathForSelectedRow.row withObject:datatns];

   // cell.lbl.text=[arr replaceObjectAtIndex: withObject:<#(nonnull id)#>];
    
    [tab reloadData];
}

- (IBAction)done:(id)sender {
    
    
    
    
  //if(cell.accessoryType==UITableViewCellAccessoryCheckmark)
    //{
//    

       
        
        SViewController *sec=[[SViewController alloc]init];
        
       // arr4=[arr objectAtIndex:2];
        
        datatns=[arr objectAtIndex:tab.indexPathForSelectedRow.row];
        
       // arr4=self.selectcell;
      
    //arr4=arr;
        
      //  [arr4 addObject:datatns];
       NSLog(@"kavi is %@",arr4);
        
        sec.data=datatns;
      sec.data4=arr4;
        sec.trans=middle;
        sec.delegate=self;
        [self.navigationController pushViewController:sec animated:YES];
    
    
    NSLog(@"not error..");
    
   // }

    
}

@end
