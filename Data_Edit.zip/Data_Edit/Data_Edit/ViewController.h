//
//  ViewController.h
//  Data_Edit
//
//  Created by kavi on 07/01/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TableViewCell.h"
#import "SViewController.h"

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate> 
{
    IBOutlet UITableView *tab;
    
    IBOutlet UINavigationBar *bar;
    IBOutlet UIBarButtonItem *done;
    
   
   NSMutableArray *arr;
    NSMutableArray *arr1;
    NSMutableArray *arr2;
    
}

@property (strong,nonatomic) NSString *datatns;
@property (strong,nonatomic) NSString *middle;
@property (nonatomic,strong)  NSMutableArray *selectcell;
@property (nonatomic,strong) NSMutableArray *deselectcell;
@property (nonatomic,strong) NSMutableArray *arr;
@property (strong,nonatomic) NSMutableArray *arr4;
@end

