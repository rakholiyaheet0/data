//
//  SViewController.m
//  Data_Edit
//
//  Created by kavi on 07/01/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import "SViewController.h"


@interface SViewController ()



@end

@implementation SViewController
@synthesize data,trans;


- (void)viewDidLoad {
    [super viewDidLoad];
    txt.delegate=self;
    
    txt.text=data;
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)save:(id)sender {
    
    trans=[[NSString alloc]init];
    
    
    //[trans addObject:txt.text];
    
    ViewController *pop=[[ViewController alloc]init];
    
    pop.middle=trans;
    pop.datatns=txt.text;
    NSLog(@"%@",trans);
    
    if ([_delegate respondsToSelector:@selector(dataFromController:)])
    {
        data=txt.text;
        
        [_delegate dataFromController:data];
    }
    
    [self.navigationController popViewControllerAnimated:YES];
    
   // [self.navigationController popViewControllerAnimated:YES];
    
}

@end
