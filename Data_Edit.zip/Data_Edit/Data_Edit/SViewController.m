//
//  SViewController.m
//  Data_Edit
//
//  Created by kavi on 07/01/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import "SViewController.h"


@interface SViewController ()



@end

@implementation SViewController
@synthesize data,trans,data4;


- (void)viewDidLoad {
    [super viewDidLoad];
   // data4=[[NSMutableArray alloc]init];
    
    NSLog(@"hahaha %@",data4);
    
    txt.delegate=self;
    
    txt.text=data;
    
           
   

        
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)save:(id)sender {
    
    data4=[[NSMutableArray alloc]init];
    //data4=NULL;
    //[edit reloadData];
    
    trans=[[NSString alloc]init];
    
    
    //[trans addObject:txt.text];
    
    ViewController *pop=[[ViewController alloc]init];
    
    pop.middle=trans;
    pop.datatns=txt.text;
    NSLog(@"%@",trans);
    
    if ([_delegate respondsToSelector:@selector(dataFromController:)])
    {
        data=txt.text;
        
        [_delegate dataFromController:data];
    }
   // data4=nil;
   // NSLog(@"%@",data4);
    txt.text=nil;
    [edit reloadData];
    [self.navigationController popViewControllerAnimated:YES];
    
    
    
   // [self.navigationController popViewControllerAnimated:YES];
    
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return data4.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    
    cell.textLabel.textAlignment=NSTextAlignmentCenter;
    
    //NSString *string=[data4 objectAtIndex:indexPath.row];
    
    
    
    UITextField *kavi=[[UITextField alloc]initWithFrame:CGRectMake(15, 3, 266, 32)];
    kavi.delegate=self;
    kavi.layer.borderWidth=1;
    kavi.layer.masksToBounds=YES;
    
    kavi.textAlignment=NSTextAlignmentCenter;
    kavi.text=[data4 objectAtIndex:indexPath.row];
    
    [kavi resignFirstResponder];
    [cell addSubview:kavi];
    
  //  cell.textLabel.text=string;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView
didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:[tableView indexPathForSelectedRow] animated:NO];
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if (cell.accessoryType == UITableViewCellAccessoryNone) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
        // Reflect selection in data model
    } else if (cell.accessoryType == UITableViewCellAccessoryCheckmark) {
        cell.accessoryType = UITableViewCellAccessoryNone;
        // Reflect deselection in data model
    }
}


@end
