//
//  TableViewCell.m
//  Data_Edit
//
//  Created by kavi on 07/01/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell
@synthesize img;

- (void)awakeFromNib {
    [super awakeFromNib];
    
    img.image=[UIImage imageNamed:@"1.png"];
    img.layer.cornerRadius=14;
    img.layer.borderWidth=1;
    img.layer.masksToBounds=YES;
       // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
