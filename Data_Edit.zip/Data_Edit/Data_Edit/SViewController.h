//
//  SViewController.h
//  Data_Edit
//
//  Created by kavi on 07/01/17.
//  Copyright © 2017 kavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"

@protocol SViewControllerDelegate <NSObject>
@required
- (void)dataFromController:(NSString *)data;
@end

@interface SViewController : UIViewController<UITextFieldDelegate>
{
    IBOutlet UITextField *txt;
    IBOutlet UIButton *save;
}

@property(strong,nonatomic) NSString *data;
@property (strong,nonatomic) NSString *trans;
@property (nonatomic, retain) NSString *data1;
@property (nonatomic, weak) id<SViewControllerDelegate> delegate;
@end
