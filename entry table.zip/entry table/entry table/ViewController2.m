//
//  ViewController2.m
//  entry table
//
//  Created by hitesh rakholiya on 16/02/17.
//  Copyright (c) 2017 hitesh rakholiya. All rights reserved.
//

#import "ViewController2.h"
#import "Constant.h"
#import <sqlite3.h>
#import "FMDatabase.h"

@interface ViewController2 ()
{
     NSString *val;
    NSData *ImageData;
    NSString *b64str;
    
    
}

@end

@implementation ViewController2

- (void)viewDidLoad {
    [super viewDidLoad];
    _txt_name.delegate=self;
    _txt_userid.delegate=self ;
    _txt_password.delegate=self;
    _txt_emailid.delegate=self;
    _txt_contactno.delegate=self;
    [_txt_userid resignFirstResponder];
    [_txt_password resignFirstResponder];
    [_txt_contactno resignFirstResponder];
    [_txt_name resignFirstResponder];
    [_txt_emailid resignFirstResponder];
    ;
    
       
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField;
{
    [self.view endEditing:YES];
    if (textField==_txt_name)
    {
        NSString *str_integer=[NSString stringWithFormat:@"%ld",(long)_txt_name.text.integerValue];
        
    
        if (_txt_name.text.length>10)
        {
                UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"enter" message:@"enter less than 10 character" delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil, nil];
                [alert show];
        }
       else if ((_txt_name.text!=str_integer))
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"enter" message:@"enter  string " delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil, nil];
            [alert show];
        }
        
        
        
    }else if(textField==_txt_userid)
    {
        
        if(_txt_userid.text.length>2)
        {
                UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"enter" message:@"enter less than 2 character" delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil, nil];
            [alert show];
        }
        
    }else if (textField==_txt_emailid)
    {
        
        
        
            NSString *emailReg = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
            NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailReg];
            
            if ([emailTest evaluateWithObject:_txt_emailid.text] == NO)
            {
                
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"enter the Valid Mail id" message:@"Please Enter Valid Email Address." delegate:nil cancelButtonTitle:@"okay" otherButtonTitles:nil];
                [alert show];
                
            }
        
        
    }
    else if (textField==_txt_password)
    {
        int numberofCharacters = 0;
        BOOL lowerCaseLetter = false,upperCaseLetter = false,digit = false,specialCharacter = 0;
        if([textField.text length] >= 10)
        {
            for (int i = 0; i < [_txt_password.text length]; i++)
            {
                unichar c = [_txt_password.text characterAtIndex:i];
                if(!lowerCaseLetter)
                {
                    lowerCaseLetter = [[NSCharacterSet lowercaseLetterCharacterSet] characterIsMember:c];
                }
                if(!upperCaseLetter)
                {
                    upperCaseLetter = [[NSCharacterSet uppercaseLetterCharacterSet] characterIsMember:c];
                }
                if(!digit)
                {
                    digit = [[NSCharacterSet decimalDigitCharacterSet] characterIsMember:c];
                }
                if(!specialCharacter)
                {
                    specialCharacter = [[NSCharacterSet symbolCharacterSet] characterIsMember:c];
                }
            }
            
            if(specialCharacter && digit && lowerCaseLetter && upperCaseLetter)
            {
                //do what u want
            }
            else
            {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                                message:@"Please Ensure that you have at least one lower case letter, one upper case letter, one digit and one special character"
                                                               delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [alert show];
            }
            
        }
        else
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                            message:@"Please Enter at least 10 password"
                                                           delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert show];
        }
    }
    else if (textField==_txt_contactno)
    {
        NSString *string_int=[NSString stringWithFormat:@"%ld",(long)_txt_contactno.text.integerValue];
        if (_txt_contactno.text.length>10)
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"error" message:@"enter 10digit" delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:@"ok",nil];
            [alert show];
        }
        else if ((_txt_contactno.text=string_int))
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"error" message:@"enter only number" delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:@"ok",nil];
            [alert show];
        
    }
    }
    return YES;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

- (IBAction)gender1:(id)sender {
    
        UISegmentedControl *segmentedControl = (UISegmentedControl *) sender;
        NSInteger gender = segmentedControl.selectedSegmentIndex;
        
        if (gender == 0) {
            val=@"male";
            NSLog(@"%@",val);
            
    }
        else{
            val=@"fmale";
            NSLog(@"%@",val);
            }
    }

- (IBAction)InsertClick:(id)sender
{
    
   ImageData=UIImagePNGRepresentation(_imageview.image);
    b64str=[ImageData base64EncodedStringWithOptions:0];
    
    NSString *insertQuery = [NSString stringWithFormat:@"INSERT INTO jig VALUES ('%@','%ld','%@','%@','%@','%@','%@')",_txt_name.text,(long)_txt_userid.text.integerValue,_txt_emailid.text,_txt_password.text,_txt_contactno.text,val,b64str];
    
    [APPDELEGATE.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
         [db executeUpdate:insertQuery];
     }];
    
    [self clearalltextfields];
    
}
- (IBAction)DeleteClick:(id)sender
{
    NSString *deleteQuery =[NSString stringWithFormat:@"DELETE  FROM jig "];
    
    [APPDELEGATE.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
         [db executeUpdate:deleteQuery];
     }];
    
    [self clearalltextfields];
    //[self clearalllabel];
    
}

- (IBAction)Select_Click:(id)sender
{
    
    
    [APPDELEGATE.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
         
         FMResultSet *resultsWithCollegeName = [db executeQuery:@"SELECT * FROM jig"];
         
         while([resultsWithCollegeName next])
         {
             
             _txt_userid.text=[NSString stringWithFormat:@"%d",[resultsWithCollegeName intForColumn:@"userid"]];
             
             _txt_emailid.text= [NSString stringWithFormat:@"%@",[resultsWithCollegeName stringForColumn:@"emailid"]];
             
             _txt_password.text=[NSString stringWithFormat:@"%@",[resultsWithCollegeName stringForColumn:@"password"]];
             _txt_contactno.text=[NSString stringWithFormat:@"%@",[resultsWithCollegeName stringForColumn:@"contactno"]];
             _txt_name.text=[NSString stringWithFormat:@"%@",[resultsWithCollegeName stringForColumn:@"name"]];
            
             ImageData=[[NSData alloc]initWithBase64EncodedString:b64str options:0];
             
             _imageview.image=[UIImage imageWithData:ImageData];
             
         }
        // [self clearalltextfields];
     }];
   
    
}

- (IBAction)Update_Click:(id)sender
{
    NSString *updateQuery = [NSString stringWithFormat:@"UPDATE jig SET name='%@',password='%@',emailid='%@',contactno='%@'  WHERE userid='%ld'",_txt_name.text,_txt_password.text,_txt_emailid.text,_txt_contactno.text,_txt_userid.text.integerValue];

 [APPDELEGATE.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
         [db executeUpdate:updateQuery];
     }];
    
    [self clearalltextfields];
    [self clearalllabel];
    
}

-(IBAction)imageselect:(id)sender;
{
    UIImagePickerController *pickerController = [[UIImagePickerController alloc]init];
    pickerController.editing=YES;
    pickerController.delegate = self;
    
    [self presentViewController:pickerController animated:YES completion:nil];

}
- (void) imagePickerController:(UIImagePickerController *)picker
         didFinishPickingImage:(UIImage *)image
                   editingInfo:(NSDictionary *)editingInfo
{
    self.imageview.image = image;
    //NSData *imagedata=[];
    
    
    [self dismissModalViewControllerAnimated:YES];
}

- (IBAction)Bulk_Insert_Click:(id)sender
{
    
    // Insert Bulk Data
    //[self Insert_Bulk_Data];
    
    // Select Bulk Data
    //[self Select_Bulk_Data];
    
}

-(void)Insert_Bulk_Data
{
    //    NSString *delete_data=[NSString stringWithFormat:@"DELETE FROM Bulk_DataTable WHERE user_id='%@'",[USERDEFAULTS valueForKey:@"current_user_id"]];
    //
    //    [APPDELEGATE.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
    //     {
    //         [db executeUpdate:delete_data];
    //     }];
    //
    //    NSString *res_st=[APPDELEGATE Convert_arr_From_Json_String:responsearr];
    //
    //    NSString *t_str=[APPDELEGATE Convert_arr_From_Json_String:top_five_art_arr];
    //
    //    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    //    [dict setObject:[USERDEFAULTS valueForKey:@"current_user_id"] forKey:@"user_id"];
    //
    //    [dict setObject:t_str forKey:@"topfive_article"];
    //    [dict setObject:res_st forKey:@"listing_article"];
    //
    //    // ADD Dictionary In database Table with  FMDATABASE AND SKDATABASE
    //
    //    //[Database insertDictionary:dict forTable:@"INSIGHT_OPENION"];
    //
    //    [APPDELEGATE.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
    //     {
    //         [db executeUpdate:@"INSERT INTO INSIGHT_OPENION (user_id,topfive_article,listing_article) VALUES (:user_id,:topfive_article,:listing_article)" withParameterDictionary:dict];
    //     }];
    
}

-(void)Select_Bulk_Data
{
    //    NSString *sqlSelectQuery =[NSString stringWithFormat:@"SELECT * FROM INSIGHT_OPENION where user_id=%ld",(long)[[USERDEFAULTS valueForKey:@"current_user_id"]integerValue]] ;
    //
    //    [APPDELEGATE.queue inTransaction:^(FMDatabase *db, BOOL *rollback)
    //     {
    //
    //         FMResultSet *dataset = [db executeQuery:sqlSelectQuery];
    //
    //         while([dataset next])
    //         {
    //             responsearr=[APPDELEGATE Convert_Json_String_From_Arr:[dataset stringForColumn:@"listing_article"]];
    //
    //
    //             top_five_art_arr=[APPDELEGATE Convert_Json_String_From_Arr:[dataset stringForColumn:@"topfive_article"]];
    //         }
    //     }];
    //
    //    if (!responsearr.count>0)
    //    {
    //        SHOW_ALERT(@"Alert",@"There is no data in database please connect internet to access this functionality", nil, @"Ok", nil);
    //        return;
    //    }
    
}
-(void)clearalltextfields
{
    _txt_userid.text=nil;
    _txt_password.text=nil;
    _txt_emailid.text=nil;
    _txt_contactno.text=nil;
    _txt_name.text=nil;
    _imageview.image=nil;
}

-(void)clearalllabel
{
//    _Name_lbl.text=nil;
//    _id_lbl.text=nil;
//    _Des_lbl.text=nil;
    _txt_name.text=nil;
}


@end
