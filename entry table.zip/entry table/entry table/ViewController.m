//
//  ViewController.m
//  entry table
//
//  Created by hitesh rakholiya on 16/02/17.
//  Copyright (c) 2017 hitesh rakholiya. All rights reserved.
//

#import "ViewController.h"
#import "ViewController2.h"
#import "ViewController3.h"
#import "userlist_ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}
-(IBAction)registerlo:(id)sender;
{
    ViewController2 *v2=[self.storyboard instantiateViewControllerWithIdentifier:@"ViewController2"];
    [self.navigationController pushViewController:v2 animated:YES];
}
- (IBAction)login:(id)sender {
    ViewController3 *v3=[self.storyboard instantiateViewControllerWithIdentifier:@"ViewController3"];
    [self.navigationController pushViewController:v3 animated:YES];
    
}
-(IBAction)userlist:(id)sender;
{
    userlist_ViewController *user=[self.storyboard instantiateViewControllerWithIdentifier:@"userlist_ViewController"];
    [self.navigationController pushViewController:user animated:YES];
}
@end
