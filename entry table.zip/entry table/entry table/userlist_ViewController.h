//
//  userlist_ViewController.h
//  entry table
//
//  Created by hitesh rakholiya on 19/02/17.
//  Copyright (c) 2017 hitesh rakholiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface userlist_ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    IBOutlet UITableView *tab;
}

@end
