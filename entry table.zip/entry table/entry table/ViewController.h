//
//  ViewController.h
//  entry table
//
//  Created by hitesh rakholiya on 16/02/17.
//  Copyright (c) 2017 hitesh rakholiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    IBOutlet UIButton *btn_register;
    IBOutlet UIButton *btn_login;
    IBOutlet UIButton *userlist;
}


@end

